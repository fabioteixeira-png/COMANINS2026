import React, { Component, useState, useEffect } from 'react';
import { deleteField } from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import { authJsonFetch, clientAuthJsonFetch } from './utils/authApi';
import { downloadInternalAccessCredentialsPdf } from './utils/internalAccessPdf';
import PublicSite from './components/PublicSite';
import InternalPortal from './components/InternalPortal';
import ClientPortal from './components/ClientPortal';
import LoginScreen from './components/LoginScreen';
import {
 Client, Instrument, CalibrationReport, ContactMessage, RncReport } from './types';
import {
 RefreshCw, Database } from 'lucide-react';
import {

  syncCustomLogo,
  saveCustomLogoConfig,
  syncHeaderLogo,
  saveHeaderLogoConfig,
  syncSitePhotosConfig,
  saveSitePhotosConfig,
  syncInstruments,
  syncReports,
  syncMessages,
  addClientDoc,
  addClientsBulkDocs,
  deleteClientDoc,
  updateClientDoc,
  addInstrumentDoc,
  addInstrumentsBulkDocs,
  deduplicateInstrumentsByCertificate,
  deleteInstrumentDoc,
  updateInstrumentDoc,
  saveCalibrationDoc,
  deleteReportDoc,
  recoverArchivedCalibrationDoc,
  prepareAdminCalibrationReplacementDoc,
  updateMessageDoc,
  addPortalUserDoc,
  updatePortalUserDoc,
  deletePortalUserDoc,
  PortalUser,
  auth,
  clientAuth
} from './lib/firebase';
import type { SavedIntake, FieldServiceRecord } from './lib/firebase';

export default function App() {
  const [viewMode, setViewMode] = useState<'public' | 'login' | 'portal' | 'client'>('public');
  const [loginTab, setLoginTab] = useState<'internal' | 'client'>('client');
  const [currentClient, setCurrentClient] = useState<Client | null>(null);

  // Firestore Real-time States
  const [clients, setClients] = useState<Client[]>([]);
  const [instruments, setInstruments] = useState<Instrument[]>([]);
  const [reports, setReports] = useState<CalibrationReport[]>([]);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [clientIntakes, setClientIntakes] = useState<SavedIntake[]>([]);
  const [clientRncReports, setClientRncReports] = useState<RncReport[]>([]);
  const [clientFieldServiceRecords, setClientFieldServiceRecords] = useState<FieldServiceRecord[]>([]);
  const [internalUsers, setInternalUsers] = useState<PortalUser[]>([]);

  const [currentInternalUser, setCurrentInternalUser] = useState<{
    name: string;
    username: string;
    role: string;
    register: string;
    permissionLevel?: string;
    accessProfileId?: string;
    accessProfileName?: string;
    allowedModules?: string[];
    editableModules?: string[];
    accessProfileVersion?: number;
  } | null>(null);

  // Custom logo state for reports and certificates
  const [customLogo, setCustomLogo] = useState<string>('');
  const [headerLogo, setHeaderLogo] = useState<string>('');
  const [sitePhotos, setSitePhotos] = useState<any[]>(() => {
    const saved = localStorage.getItem('comanins_site_photos');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const handleSaveCustomLogo = async (logoDataUrl: string) => {
    await saveCustomLogoConfig(logoDataUrl);
    await saveHeaderLogoConfig(logoDataUrl);
  };

  const activeLogo = headerLogo || customLogo;

  // Loading and Error boundaries
  const [isLoading, setIsLoading] = useState(true);
  const [quotaExceededNotice, setQuotaExceededNotice] = useState(false);

  useEffect(() => {
    const handleQuota = () => setQuotaExceededNotice(true);
    window.addEventListener('firestore-quota-exceeded', handleQuota);
    return () => window.removeEventListener('firestore-quota-exceeded', handleQuota);
  }, []);

  // Public site only subscribes to public presentation data. Operational
  // collections are started only after the corresponding account is authenticated.
  useEffect(() => {
    let unsubs: (() => void)[] = [];

    const initPublicFirebaseSync = async () => {
      setIsLoading(true);
      try {
        const u6 = await syncCustomLogo(setCustomLogo);
        const u7 = await syncHeaderLogo(setHeaderLogo);
        const u8 = await syncSitePhotosConfig((photos) => {
          if (photos && photos.length > 0) {
            setSitePhotos(photos);
          }
        });
        unsubs = [u6, u7, u8];
      } catch (err) {
        console.error('Error initializing public Firestore sync:', err);
      } finally {
        setIsLoading(false);
      }
    };

    initPublicFirebaseSync();

    return () => {
      unsubs.forEach(unsub => unsub && unsub());
    };
  }, []);

  // Internal users keep the existing real-time Firestore subscriptions. Client
  // users receive only their own operational data from the authenticated server
  // endpoint, never from a global Firestore listener.
  useEffect(() => {
    let cancelled = false;
    let unsubs: (() => void)[] = [];

    const clearClientPortalData = () => {
      setClientIntakes([]);
      setClientRncReports([]);
      setClientFieldServiceRecords([]);
    };

    const startAuthenticatedDataSync = async () => {
      if (viewMode === 'portal' && currentInternalUser) {
        clearClientPortalData();
        try {
          const u2 = await syncInstruments(setInstruments);
          const u3 = await syncReports(setReports);
          const u4 = await syncMessages(setMessages);
          if (cancelled) {
            u2?.();
            u3?.();
            u4?.();
            return;
          }
          unsubs = [u2, u3, u4];
        } catch (err) {
          console.error('Error initializing internal operational sync:', err);
        }
        return;
      }

      if (viewMode === 'client' && currentClient) {
        setInstruments([]);
        setReports([]);
        setMessages([]);
        clearClientPortalData();
        try {
          // Remove technical caches from older versions so a client session can
          // never inherit a previous internal user's locally persisted dataset.
          try {
            localStorage.removeItem('comanins_cache_instruments');
            localStorage.removeItem('comanins_cache_calibrationReports');
            localStorage.removeItem('comanins_cache_savedIntakes');
            localStorage.removeItem('comanins_cache_rncReports');
          } catch (e) {}

          const response = await clientAuthJsonFetch('/api/client-portal/data');
          const data = await response.json();
          if (!response.ok || data?.success !== true) {
            throw new Error(data?.error || 'CLIENT_PORTAL_DATA_UNAVAILABLE');
          }
          if (cancelled) return;

          setInstruments(Array.isArray(data.instruments) ? data.instruments : []);
          setReports(Array.isArray(data.reports) ? data.reports : []);
          setClientIntakes(Array.isArray(data.clientIntakes) ? data.clientIntakes : []);
          setClientRncReports(Array.isArray(data.rncReports) ? data.rncReports : []);
          setClientFieldServiceRecords(Array.isArray(data.fieldServiceRecords) ? data.fieldServiceRecords : []);
        } catch (err) {
          console.error('Error loading isolated client portal data:', err);
          if (!cancelled) {
            setInstruments([]);
            setReports([]);
            clearClientPortalData();
          }
        }
        return;
      }

      setInstruments([]);
      setReports([]);
      setMessages([]);
      clearClientPortalData();
    };

    startAuthenticatedDataSync();

    return () => {
      cancelled = true;
      unsubs.forEach((unsub) => unsub && unsub());
    };
  }, [viewMode, currentInternalUser, currentClient]);

  // Client master data is loaded through the authenticated backend. This avoids
  // leaving a Firestore listener permanently open and makes authorization errors
  // explicit instead of silently replacing the directory with an empty array.
  useEffect(() => {
    let cancelled = false;

    const loadClients = async () => {
      if (viewMode !== 'portal' || !currentInternalUser) {
        setClients([]);
        try { localStorage.removeItem('comanins_cache_clients'); } catch (e) {}
        return;
      }

      try {
        const response = await authJsonFetch('/api/internal/clients');
        const data = await response.json().catch(() => ({}));
        if (!response.ok || data?.success !== true || !Array.isArray(data?.clients)) {
          throw new Error(data?.error || 'CLIENT_DIRECTORY_UNAVAILABLE');
        }
        if (!cancelled) setClients(data.clients);
      } catch (err) {
        console.error('Error loading authenticated clients directory:', err);
        if (!cancelled) setClients([]);
      }
    };

    loadClients();
    return () => { cancelled = true; };
  }, [viewMode, currentInternalUser]);

  // Employee directory is loaded through the authenticated backend. Admin/RH
  // receive the full RH profile set; other internal roles receive only the
  // operational directory fields required by the portal.
  useEffect(() => {
    let cancelled = false;

    const loadInternalUsers = async () => {
      if (viewMode !== 'portal' || !currentInternalUser) {
        setInternalUsers([]);
        try {
          localStorage.removeItem('comanins_portal_users_cache');
        } catch (e) {}
        return;
      }

      try {
        const response = await authJsonFetch('/api/internal/portal-users');
        const data = await response.json();
        if (!response.ok) {
          throw new Error(data?.error || 'Não foi possível carregar o diretório interno.');
        }
        if (!cancelled) {
          setInternalUsers(Array.isArray(data?.users) ? data.users : []);
        }
      } catch (err) {
        console.error('Error loading protected internal user directory:', err);
        if (!cancelled) setInternalUsers([]);
      }
    };

    loadInternalUsers();

    return () => {
      cancelled = true;
    };
  }, [viewMode, currentInternalUser]);

  // Remove legacy employee cache left by older versions.
  useEffect(() => {
    try {
      localStorage.removeItem('comanins_portal_users_cache');
    } catch (e) {}
  }, []);

  // CLIENT CRUD ACTIONS (Firestore)
  const handleAddClient = async (newClientData: Omit<Client, 'id'>) => {
    try {
      const saved = await addClientDoc(newClientData);
      setClients(prev => [saved, ...prev.filter(c => c.id !== saved.id)]);
      return saved;
    } catch (err: any) {
      console.error('Error adding client to Firestore:', err);

      alert('Erro no Firestore: ' + (err.message || err.toString()));
      throw err;

    }
  };

  const handleAddClientsBulk = async (list: Omit<Client, 'id'>[]) => {
    try {
      const added = await addClientsBulkDocs(list);
      setClients(prev => [...added, ...prev]);
      return added;
    } catch (err) {
      console.error('Error bulk adding clients to Firestore:', err);

      return [];
    }
  };

  const handleDeleteClient = async (id: string) => {
    try {
      setClients(prev => prev.filter(c => c.id !== id));
      await deleteClientDoc(id);
    } catch (err) {
      console.error('Error deleting client from Firestore:', err);

    }
  };

  const handleUpdateClient = async (updatedClient: Client) => {
    try {
      setClients(prev => prev.map(c => c.id === updatedClient.id ? updatedClient : c));
      await updateClientDoc(updatedClient);
    } catch (err) {
      console.error('Error updating client in Firestore:', err);
    }
  };

  // INSTRUMENT CRUD ACTIONS (Firestore)
  const handleAddInstrument = async (newInstData: Omit<Instrument, 'id' | 'status' | 'lastCalibrationDate' | 'nextCalibrationDate'>) => {
    try {
      const saved = await addInstrumentDoc(newInstData);
      setInstruments(prev =>
        deduplicateInstrumentsByCertificate([
          saved,
          ...prev.filter(i => i.id !== saved.id),
        ]),
      );
      return saved;
    } catch (err) {
      console.error('Error adding instrument to Firestore:', err);
      throw err;

    }
  };

  const handleAddInstrumentsBulk = async (list: Omit<Instrument, 'id' | 'status' | 'lastCalibrationDate' | 'nextCalibrationDate'>[]) => {
    try {
      const added = await addInstrumentsBulkDocs(list);
      setInstruments(prev => [...added, ...prev]);
      return added;
    } catch (err) {
      console.error('Error bulk adding instruments to Firestore:', err);

      return [];
    }
  };

  const handleDeleteInstrument = async (id: string) => {
    try {
      setInstruments(prev => prev.filter(i => i.id !== id));
      await deleteInstrumentDoc(id);
    } catch (err) {
      console.error('Error deleting instrument from Firestore:', err);

    }
  };

  const handleUpdateInstrumentStatus = async (id: string, status: Instrument['status']) => {
    try {
      await updateInstrumentDoc(id, { status });
      setInstruments(prev => prev.map(i => i.id === id ? { ...i, status } : i));
    } catch (err) {
      console.error('Error updating instrument status in Firestore:', err);
      throw err;
    }
  };

  // CALIBRATION BENCH SUBMIT ACTION (Firestore)
  const handleSaveCalibration = async (sessionData: any) => {
    try {
      const activeInst = instruments.find(item => item.id === sessionData.instrumentId);
      if (!activeInst) throw new Error('INSTRUMENT_NOT_FOUND');

      const result = await saveCalibrationDoc(sessionData, activeInst);

      // Do not wait for realtime listeners before allowing the certificate to
      // be opened. The atomic write already succeeded, so reflect that result
      // immediately in the application state.
      setReports(prev => [
        result.report,
        ...prev.filter(report => report.id !== result.report.id),
      ]);
      setInstruments(prev => prev.map(item =>
        item.id === result.instrument.id ? result.instrument : item,
      ));

      return result;
    } catch (err) {
      console.error('Error saving calibration to Firestore:', err);
      throw err;
    }
  };

  const handleDeleteReport = async (reportId: string) => {
    try {
      const result = await deleteReportDoc(reportId);
      setReports(prev => prev.filter(r => r.id !== reportId));

      if (result.instrument) {
        setInstruments(prev => prev.map(instrument =>
          instrument.id === result.instrumentId
            ? result.instrument as Instrument
            : instrument
        ));
      }
      return result;
    } catch (err) {
      console.error('Error deleting calibration report from Firestore:', err);
      throw err;
    }
  };

  const handlePrepareCalibration = async (instrumentId: string) => {
    try {
      const result = await recoverArchivedCalibrationDoc(instrumentId);
      if (result.instrument) {
        setInstruments(prev => prev.map(instrument =>
          instrument.id === instrumentId
            ? result.instrument as Instrument
            : instrument
        ));
      }
      return result;
    } catch (err) {
      console.error('Error recovering archived calibration:', err);
      throw err;
    }
  };

  const handleAdminReplaceCalibration = async (
    instrumentId: string,
    credentials: { username: string; password: string; reason: string },
  ) => {
    try {
      const result = await prepareAdminCalibrationReplacementDoc(instrumentId, credentials);
      const archived = new Set(result.archivedReportIds || []);
      setReports(prev => prev.filter(report => !archived.has(report.id)));
      if (result.instrument) {
        setInstruments(prev => prev.map(instrument =>
          instrument.id === instrumentId ? result.instrument : instrument,
        ));
      }
      return result;
    } catch (err) {
      console.error('Error preparing administrative calibration replacement:', err);
      throw err;
    }
  };

  // INBOX LEADS ACTIONS (Firestore)
  const handleUpdateMessageStatus = async (id: string, status: ContactMessage['status']) => {
    try {
      await updateMessageDoc(id, status);
    } catch (err) {
      console.error('Error updating contact message in Firestore:', err);

    }
  };

  const handleSubmitContactFromPublic = async (contactData: Omit<ContactMessage, 'id' | 'date' | 'status'>): Promise<boolean> => {
    try {
      const response = await fetch('/api/send-contact-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(contactData),
      });
      const result = await response.json().catch(() => ({}));
      return response.ok && result?.success === true;
    } catch (err) {
      console.error('Error submitting public contact:', err);
      return false;
    }
  };

  // USER MANAGEMENT ACTIONS (Firestore)
  const handleAddInternalUser = async (newUser: { name: string; username: string; role: string; permissionLevel?: string; accessProfileId?: string; register: string; password?: string }) => {
    try {
      const email = `${newUser.username.toLowerCase()}@comanins.internal`;
      const initialAccessProfileId = newUser.accessProfileId || 'limited';
      const generatedTempPass = (() => {
        const bytes = new Uint32Array(4);
        crypto.getRandomValues(bytes);
        return `Tmp#${Array.from(bytes).map(v => v.toString(36)).join('')}Aa1!`;
      })();
      const tempPass = newUser.password || generatedTempPass;
      
      const res = await authJsonFetch('/api/auth/create-user', {
        method: 'POST',
        body: JSON.stringify({
          email,
          password: tempPass,
          role: newUser.role,
          accessProfileId: initialAccessProfileId,
        })
      });
      const data = await res.json();
      
      if (!res.ok || !data?.uid) {
        throw new Error(data.error || 'Erro ao criar conta no Firebase Auth');
      }

      const existingPortalUser = internalUsers.find(
        (user) => user.username.trim().toLowerCase() === newUser.username.trim().toLowerCase()
      );
      if (existingPortalUser) {
        if (existingPortalUser.authUid && existingPortalUser.authUid !== data.uid) {
          throw new Error('Este username já está vinculado a outra conta Firebase.');
        }

        await updatePortalUserDoc(existingPortalUser.id, {
          authUid: data.uid,
          authEmail: email,
        });
        setInternalUsers(prev => prev.map(user =>
          user.id === existingPortalUser.id
            ? { ...user, authUid: data.uid, authEmail: email }
            : user
        ));

        alert('Este usuário já existia no portal. A conta Firebase foi vinculada ao cadastro existente sem criar duplicidade.');
        return;
      }

      const cleanUser = Object.entries(newUser).reduce((acc, [key, value]) => {
        if (value !== undefined) {
          acc[key] = value;
        }
        return acc;
      }, {} as any);
      
      cleanUser.passwordChangeRequired = true;
      cleanUser.authUid = data.uid;
      cleanUser.authEmail = email;
      cleanUser.accessProfileId = initialAccessProfileId;
      cleanUser.permissionLevel = initialAccessProfileId === 'limited' ? 'Limitado' : 'Padrão';
      delete cleanUser.password;

      const savedUser = await addPortalUserDoc(cleanUser);
      setInternalUsers(prev => [savedUser, ...prev.filter(user => user.id !== savedUser.id)]);
      if (data.alreadyExists) {
        alert('A conta Firebase já existia. O cadastro foi vinculado sem alterar a senha atual dessa conta.');
      } else {
        try {
          const pdfName = await downloadInternalAccessCredentialsPdf({
            collaboratorName: newUser.name,
            username: newUser.username.trim().toLowerCase(),
            temporaryPassword: tempPass,
            siteUrl: window.location.origin,
          });
          alert(`Usuário criado com sucesso.\n\nO PDF de acesso “${pdfName}” foi baixado e já pode ser enviado ao colaborador.`);
        } catch (pdfError) {
          console.error('Error generating internal access PDF:', pdfError);
          try {
            await navigator.clipboard.writeText(`Usuário: ${newUser.username.trim().toLowerCase()}\nSenha temporária: ${tempPass}\nAcesso: ${window.location.origin}`);
            alert('Usuário criado com sucesso. Não foi possível gerar o PDF, mas as credenciais foram copiadas para a área de transferência.');
          } catch (clipboardError) {
            console.error('Error copying temporary credentials:', clipboardError);
            window.prompt('Não foi possível gerar o PDF. Copie agora a senha temporária:', tempPass);
          }
        }
      }
    } catch (err: any) {
      console.error('Error adding internal user to Firestore:', err);
      alert('Erro ao cadastrar usuário: ' + err.message);
    }
  };

  const handleUpdateInternalUser = async (id: string, updates: Partial<PortalUser>) => {
    try {
      const { password: _legacyPassword, ...passwordFreeUpdates } = updates as Partial<PortalUser> & { password?: string };
      const cleanUpdates = Object.entries(passwordFreeUpdates).reduce((acc, [key, value]) => {
        if (value === null) {
          acc[key] = deleteField();
        } else if (value !== undefined) {
          acc[key] = value;
        }
        return acc;
      }, {} as any);
      await updatePortalUserDoc(id, cleanUpdates);
      setInternalUsers(prev => prev.map(user => {
        if (user.id !== id) return user;
        const nextUser: any = { ...user };
        Object.entries(passwordFreeUpdates).forEach(([key, value]) => {
          if (value === null) {
            delete nextUser[key];
          } else if (value !== undefined) {
            nextUser[key] = value;
          }
        });
        return nextUser as PortalUser;
      }));
    } catch (err: any) {
      console.error('Error updating internal user in Firestore:', err);
      if (err.message && err.message.includes("exceeds the maximum allowed size")) {
         alert("⚠️ ERRO: ARMAZENAMENTO EXCEDIDO!\n\nAs alterações não foram salvas porque o tamanho total dos dados (incluindo imagens e PDFs anexados) ultrapassou o limite do banco de dados (1MB). Apague alguns anexos antes de salvar.");
      } else {
         alert("⚠️ Erro ao salvar alterações: " + err.message);
      }
    }
  };

  const handleAssignAccessProfile = async (
    id: string,
    accessProfileId: string,
  ): Promise<PortalUser> => {
    const response = await authJsonFetch(
      `/api/internal/portal-users/${encodeURIComponent(id)}/access-profile`,
      {
        method: 'PUT',
        body: JSON.stringify({ accessProfileId }),
      },
    );
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data?.user) {
      throw new Error(data?.error || 'ACCESS_PROFILE_ASSIGNMENT_FAILED');
    }

    const updatedUser = data.user as PortalUser;
    setInternalUsers(prev => prev.map(user => user.id === id ? { ...user, ...updatedUser } : user));
    return updatedUser;
  };

  const handleDeleteInternalUser = async (username: string) => {
    try {
      const target = internalUsers.find(u => u.username === username);
      if (target) {
        await deletePortalUserDoc(target.id);
        setInternalUsers(prev => prev.filter(user => user.id !== target.id));
      }
    } catch (err) {
      console.error('Error deleting internal user from Firestore:', err);

    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-center font-sans">
        <div className="text-center space-y-4">
          <div className="relative inline-block">
            <RefreshCw className="h-12 w-12 text-teal-400 animate-spin mx-auto" />
            <Database className="h-5 w-5 text-amber-400 absolute inset-0 m-auto" />
          </div>
          <h2 className="text-xl font-display font-extrabold tracking-tight text-white">Carregando COMANINS Suite</h2>
          <p className="text-teal-400 text-xs font-mono uppercase tracking-wider flex items-center justify-center space-x-1.5">
            <span>Conectando ao banco de dados Firestore...</span>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen bg-slate-950">
      {quotaExceededNotice && (
        <div className="bg-amber-500/90 text-slate-950 px-4 py-2.5 text-xs font-semibold flex items-center justify-between shadow-md z-50 sticky top-0 backdrop-blur-sm border-b border-amber-600/30">
          <div className="flex items-center space-x-2">
            <span className="bg-amber-950 text-amber-200 text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase tracking-wider">Quota Firestore Excedida</span>
            <span>Os dados do banco <strong>não foram apagados</strong>! A cota diária de leitura do Firebase foi atingida. Exibindo cópia local offline.</span>
          </div>
          <button 
            onClick={() => setQuotaExceededNotice(false)}
            className="ml-4 bg-amber-950/20 hover:bg-amber-950/40 text-slate-950 px-2 py-0.5 rounded text-[11px] font-bold cursor-pointer transition-colors"
          >
            Fechar ✕
          </button>
        </div>
      )}
      {/* Switching Views */}
      <div className="transition-all duration-300">
        {viewMode === 'public' ? (
          <PublicSite
            customLogo={activeLogo}
            sitePhotos={sitePhotos}
            onNavigateToPortal={(tab) => {
              setLoginTab(tab || 'client');
              setViewMode('login');
            }}
            onSubmitContact={handleSubmitContactFromPublic}
          />
        ) : viewMode === 'login' ? (
          <LoginScreen
            customLogo={activeLogo}
            initialTab={loginTab}
            internalUsers={internalUsers}
            onUpdateInternalUser={handleUpdateInternalUser}
            onLoginSuccessInternal={(user) => {
              setCurrentInternalUser(user);
              setViewMode('portal');
            }}
            onLoginSuccessClient={(client) => {
              setCurrentClient(client);
              setViewMode('client');
            }}
            onBack={() => setViewMode('public')}
          />
        ) : viewMode === 'client' && currentClient ? (
          <ClientPortal
            client={currentClient}
            instruments={instruments}
            reports={reports}
            clientIntakes={clientIntakes}
            rncReports={clientRncReports}
            fieldServiceRecords={clientFieldServiceRecords}
            customLogo={activeLogo}
            onLogout={async () => {
              try {
                await signOut(clientAuth);
              } finally {
                setCurrentClient(null);
                setClientIntakes([]);
                setClientRncReports([]);
                setClientFieldServiceRecords([]);
                setInstruments([]);
                setReports([]);
                setViewMode('public');
              }
            }}
          />
        ) : (
          <InternalPortal
            onBackToSite={() => setViewMode('public')}
            currentUser={currentInternalUser}
            internalUsers={internalUsers}
            onAddInternalUser={handleAddInternalUser}
            onUpdateInternalUser={handleUpdateInternalUser}
            onAssignAccessProfile={handleAssignAccessProfile}
            onDeleteInternalUser={handleDeleteInternalUser}
            onLogout={async () => {
              try {
                await signOut(auth);
              } finally {
                setCurrentInternalUser(null);
                setInternalUsers([]);
                try { localStorage.removeItem('comanins_portal_users_cache'); } catch (e) {}
                setViewMode('public');
              }
            }}
            clients={clients}
            instruments={instruments}
            reports={reports}
            messages={messages}
            customLogo={activeLogo}
            onSaveCustomLogo={handleSaveCustomLogo}
            onAddClient={handleAddClient}
            onUpdateClient={handleUpdateClient}
            onAddClientsBulk={handleAddClientsBulk}
            onAddInstrument={handleAddInstrument}
            onAddInstrumentsBulk={handleAddInstrumentsBulk}
            onDeleteClient={handleDeleteClient}
            onDeleteInstrument={handleDeleteInstrument}
            onUpdateInstrumentStatus={handleUpdateInstrumentStatus}
            onSaveCalibration={handleSaveCalibration}
            onDeleteReport={handleDeleteReport}
            onPrepareCalibration={handlePrepareCalibration}
            onAdminReplaceCalibration={handleAdminReplaceCalibration}
            onUpdateMessageStatus={handleUpdateMessageStatus}
          />
        )}
      </div>
    </div>
  );
}
