import React, { useState, useEffect, useRef, useMemo, useDeferredValue } from 'react';
import { compressImageToWebResolution } from '../lib/imageCompressor';
import { Upload, FileSpreadsheet, Plus, Save, X, Camera, RefreshCw, Trash2, Search, Download, ChevronLeft, ChevronRight, FileDown, Columns, Edit2, ChevronUp, ChevronDown, ChevronsUpDown, Printer } from 'lucide-react';
import * as XLSX from 'xlsx';
import { Client, Instrument } from '../types';
import {
  FieldServiceRecord,
  syncFieldServiceRecords,
  addFieldServiceRecord,
  updateFieldServiceRecord,
  bulkUpsertFieldServiceRecords,
  deleteFieldServiceRecord, clearAllFieldServiceRecords, syncInstruments, syncClients, refreshFieldServiceRecords
} from '../lib/firebase';
import { authJsonFetch, verifyAdminCredentials } from '../utils/authApi';
import { buildFieldServiceA4Workbook } from '../utils/fieldServiceA4Workbook';

const parseDateForSort = (dString: string) => {
  if (!dString) return 0;
  if (typeof dString === 'number') {
     return new Date(Math.round((dString - 25569) * 86400 * 1000)).getTime();
  }
  const parts = String(dString).split('/');
  if (parts.length === 3) {
    return new Date(`${parts[2]}-${parts[1]}-${parts[0]}T00:00:00`).getTime();
  }
  return new Date(dString).getTime() || 0;
};

const COLUMNS = [
  { id: 'certificate', label: 'Certificado', minW: '120px' },
  { id: 'dataCalibracao', label: 'Data Calibração', minW: '120px' },
  { id: 'interventionDate', label: 'Data Intervenção', minW: '120px' },
  { id: 'tag', label: 'TAG do Cliente', minW: '140px' },
  { id: 'equipamento', label: 'Equipamento', minW: '150px' },
  { id: 'localizacao', label: 'Localização', minW: '150px' },
  { id: 'technician', label: 'Técnico', minW: '120px' },
  { id: 'area', label: 'Área', minW: '120px' },
  { id: 'range', label: 'Range', minW: '120px' },
  { id: 'operacao', label: 'Operação', minW: '120px' },
  { id: 'unidadeMedida', label: 'UM', minW: '100px' },
  { id: 'categoria', label: 'Categoria', minW: '120px' },
  { id: 'emissaoPdf', label: 'Emissão PDF', minW: '100px' },
  { id: 'ordemServico', label: 'OS', minW: '100px' },
  { id: 'tipoServico', label: 'Tipo Serv.', minW: '120px' },
  { id: 'observacao', label: 'Observação', minW: '150px' },
  { id: 'unidade', label: 'Unidade', minW: '120px' },
  { id: 'cliente', label: 'Cliente', minW: '150px' },
] as const;

type FieldServiceImportProgress = {
  percent: number;
  stage: string;
  processed: number;
  total: number;
};

const yieldToBrowser = () => new Promise<void>((resolve) => window.setTimeout(resolve, 0));

const parseFieldServiceExcelInWorker = (buffer: ArrayBuffer): Promise<Record<string, any>[]> =>
  new Promise((resolve, reject) => {
    const worker = new Worker(new URL('../workers/fieldServiceExcelWorker.ts', import.meta.url), { type: 'module' });
    const finish = () => worker.terminate();

    worker.onmessage = (event: MessageEvent<{ type: 'parsed' | 'error'; rows?: Record<string, any>[]; message?: string }>) => {
      if (event.data.type === 'parsed') {
        finish();
        resolve(event.data.rows || []);
        return;
      }
      finish();
      reject(new Error(event.data.message || 'Erro ao interpretar a planilha Excel.'));
    };

    worker.onerror = (event) => {
      finish();
      reject(new Error(event.message || 'Erro no processamento da planilha Excel.'));
    };

    worker.postMessage({ buffer }, [buffer]);
  });

export interface FieldServiceCertificateContext {
  fieldServiceRecordId: string;
  clientId?: string;
  cliente?: string;
  unidade?: string;
}

interface FieldServiceProps {
  canEdit?: boolean;
  canClearData?: boolean;
  onPrintCertificate?: (
    instId: string,
    tagData: string,
    equipmentData: string,
    context: FieldServiceCertificateContext,
  ) => void;
}
export default function FieldService({ canEdit = false, canClearData = false, onPrintCertificate }: FieldServiceProps = {}) {
  const [records, setRecords] = useState<FieldServiceRecord[]>([]);
  const [instruments, setInstruments] = useState<Instrument[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(100);

  // Filter states
  const [filters, setFilters] = useState<Record<string, string>>({
    certificate: '', dataCalibracao: '', cliente: '', tag: '', equipamento: '', localizacao: '',
    interventionDate: '', technician: '', area: '', range: '',
    operacao: '', unidadeMedida: '', categoria: '', emissaoPdf: '',
    ordemServico: '', tipoServico: '', observacao: '', unidade: ''
  });

  // Column Visibility State
  const [visibleColumns, setVisibleColumns] = useState<Record<string, boolean>>({
    certificate: true, dataCalibracao: true, cliente: true, tag: true, equipamento: true,
    localizacao: false, interventionDate: true, technician: true, area: false,
    range: false, operacao: false, unidadeMedida: false, categoria: false,
    emissaoPdf: false, ordemServico: true, tipoServico: true, observacao: false, unidade: false
  });
  const [showColumnMenu, setShowColumnMenu] = useState(false);
  const [selectedRecordIds, setSelectedRecordIds] = useState<Set<string>>(() => new Set());



  // Sorting State
  const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' } | null>({ key: 'interventionDate', direction: 'desc' });

  const handleSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const [editingCell, setEditingCell] = useState<{rowId: string, colId: string} | null>(null);

  const handleInlineSave = async (record: FieldServiceRecord, colId: string, newVal: string) => {
    if (!canEdit) {
      setEditingCell(null);
      alert("Seu perfil possui somente permissão de visualização no módulo Serviço de Campo.");
      return;
    }

    const previousValue = String((record as any)[colId] || '');
    if (previousValue === newVal) {
      setEditingCell(null);
      return;
    }

    if (colId === 'certificate' && newVal.trim() !== '') {
      const normalizedCertificate = normalizeCertificateIdentity(newVal);
      const isDup = records.some(
        (r) => normalizeCertificateIdentity(r.certificate) === normalizedCertificate && r.id !== record.id,
      );
      if (isDup) {
        alert("Erro: Este Certificado já está registrado na planilha!");
        return;
      }
    }

    if (colId === 'tag' && newVal.trim() !== '') {
      const normalizedTag = normalizeIdentityValue(newVal);
      const isDup = records.some(
        (r) => normalizeIdentityValue(r.tag) === normalizedTag && r.id !== record.id,
      );
      if (isDup) {
        alert("Erro: Esta TAG já está registrada na planilha!");
        return;
      }
    }

    const previousCalibrationDate = record.dataCalibracao || '';
    const previousClientId = record.clientId || '';
    const updatePayload: Partial<FieldServiceRecord> = { [colId]: newVal } as Partial<FieldServiceRecord>;

    if (colId === 'certificate') {
      const linkedInstrument = findInstrumentByCertificate(newVal);
      updatePayload.certificate = newVal.trim().toUpperCase();
      updatePayload.dataCalibracao = linkedInstrument?.lastCalibrationDate || '';
      // O certificado não altera mais o cliente do registro.
      updatePayload.clientId = resolveClientId(record);
    }

    if (colId === 'cliente') {
      updatePayload.cliente = newVal;
      updatePayload.clientId = resolveClientId({ ...record, cliente: newVal });
    }

    // Atualização otimista: a célula não volta para o certificado antigo enquanto
    // o Firestore confirma a gravação. O snapshot local usa o mesmo payload persistido.
    setRecords((current) => current.map((item) => (
      item.id === record.id ? { ...item, ...updatePayload } as FieldServiceRecord : item
    )));
    setEditingCell(null);

    try {
      await updateFieldServiceRecord(record.id, updatePayload);
    } catch (e) {
      console.error(e);
      setRecords((current) => current.map((item) => (
        item.id === record.id
          ? {
              ...item,
              [colId]: previousValue,
              ...(colId === 'certificate'
                ? { dataCalibracao: previousCalibrationDate, clientId: previousClientId }
                : {}),
            } as FieldServiceRecord
          : item
      )));
      alert(`${e instanceof Error ? e.message : "Erro ao salvar célula."} O valor anterior foi restaurado.`);
    }
  };

  const handleDeleteRecord = async (id: string) => {
    if (!canEdit) {
      alert("Seu perfil possui somente permissão de visualização no módulo Serviço de Campo.");
      return;
    }
    const adminUsername = prompt("Digite o usuário do administrador:");
    if (adminUsername === null) return;
    const pwd = prompt("Digite a senha do administrador para excluir este registro:");
    if (pwd === null) return;

    try {
      const isAdminValid = await verifyAdminCredentials(adminUsername, pwd);
      if (!isAdminValid) {
        alert("Credencial administrativa inválida.");
        return;
      }
      if (confirm("Tem certeza que deseja excluir?")) {
        await deleteFieldServiceRecord(id);
      }
    } catch (e: any) {
      console.error(e);
      alert(e?.message || "Erro ao validar autorização administrativa.");
    }
  };

  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState<Partial<FieldServiceRecord>>({});

  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState<FieldServiceImportProgress>({
    percent: 0,
    stage: '',
    processed: 0,
    total: 0,
  });
  const [isRefreshingRecords, setIsRefreshingRecords] = useState(false);
  const [showClearDataModal, setShowClearDataModal] = useState(false);
  const [clearDataPassword, setClearDataPassword] = useState('');
  const [clearDataError, setClearDataError] = useState('');
  const [isClearingData, setIsClearingData] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const excelInputRef = useRef<HTMLInputElement>(null);
  const topScrollRef = useRef<HTMLDivElement>(null);
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const [tableScrollWidth, setTableScrollWidth] = useState(0);

  useEffect(() => {
    if (!canEdit) {
      setEditingCell(null);
      setShowAddModal(false);
      setFormData({});
    }
    if (!canClearData) {
      setShowClearDataModal(false);
      setClearDataPassword('');
      setClearDataError('');
    }
  }, [canEdit, canClearData]);

  useEffect(() => {
    let disposed = false;
    let unsubscribeInst: Promise<() => void> | null = null;
    const unsubscribeClients = syncClients((data) => {
      if (!disposed) setClients(data);
    });
    const unsubscribe = syncFieldServiceRecords((data) => {
      if (disposed) return;
      setRecords(data);
      setIsLoading(false);

      // Serviço de Campo é prioridade. A carga pesada de instrumentos começa
      // somente depois de o snapshot do serviço já estar disponível, evitando
      // disputar rede/CPU durante a abertura da aba.
      if (!unsubscribeInst) {
        unsubscribeInst = syncInstruments((instrumentData) => {
          if (!disposed) setInstruments(instrumentData);
        });
      }
    });
    return () => {
      disposed = true;
      unsubscribe.then(unsub => unsub());
      unsubscribeInst?.then(unsub => unsub());
      unsubscribeClients.then(unsub => unsub());
    };
  }, []);

  // Mantém a tela atualizada sem exigir o botão manual. O cache atual permanece
  // visível enquanto uma atualização completa e silenciosa ocorre em segundo plano.
  useEffect(() => {
    let disposed = false;
    const refreshWhenReturning = () => {
      if (disposed || document.visibilityState !== 'visible') return;
      refreshFieldServiceRecords({ silent: true }).catch((error) => {
        console.warn('Atualização automática de Serviço de Campo falhou:', error);
      });
    };

    window.addEventListener('focus', refreshWhenReturning);
    document.addEventListener('visibilitychange', refreshWhenReturning);
    refreshWhenReturning();
    return () => {
      disposed = true;
      window.removeEventListener('focus', refreshWhenReturning);
      document.removeEventListener('visibilitychange', refreshWhenReturning);
    };
  }, []);

  const normalizeKey = (k: string) => k.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '');

  const normalizeIdentityValue = (value: unknown): string =>
    String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .trim()
      .replace(/\s+/g, ' ')
      .toUpperCase();

  const TAG_IMPORT_PLACEHOLDERS = new Set([
    '0',
    '-',
    'N/A',
    'NA',
    'SEM TAG',
    'S/T',
    'ST',
    'CAD. TAG',
    'CAD TAG',
  ]);

  const normalizeImportTag = (value: unknown): string => {
    const normalized = normalizeIdentityValue(value);
    return TAG_IMPORT_PLACEHOLDERS.has(normalized) ? '' : normalized;
  };

  const FIELD_SERVICE_IMPORT_COMPARISON_FIELDS: Array<keyof FieldServiceRecord> = [
    'cliente',
    'equipamento',
    'localizacao',
    'dataCalibracao',
    'interventionDate',
    'technician',
    'area',
    'range',
    'operacao',
    'unidadeMedida',
    'categoria',
    'emissaoPdf',
    'ordemServico',
    'tipoServico',
    'observacao',
    'unidade',
  ];

  const normalizeImportDate = (value: unknown): string => {
    if (value instanceof Date && !Number.isNaN(value.getTime())) {
      const day = String(value.getDate()).padStart(2, '0');
      const month = String(value.getMonth() + 1).padStart(2, '0');
      return `${day}/${month}/${value.getFullYear()}`;
    }

    const raw = String(value ?? '').trim();
    if (!raw) return '';

    const iso = raw.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
    if (iso) {
      return `${iso[3].padStart(2, '0')}/${iso[2].padStart(2, '0')}/${iso[1]}`;
    }

    const br = raw.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})/);
    if (br) {
      return `${br[1].padStart(2, '0')}/${br[2].padStart(2, '0')}/${br[3]}`;
    }

    const digits = raw.replace(/\D/g, '');
    if (digits.length === 8) {
      return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4, 8)}`;
    }

    return raw;
  };

  const normalizeImportComparisonValue = (field: keyof FieldServiceRecord, value: unknown): string => {
    if (field === 'interventionDate' || field === 'dataCalibracao') {
      return normalizeIdentityValue(normalizeImportDate(value));
    }
    return normalizeIdentityValue(value);
  };

  const buildFieldServiceContentFingerprint = (record: Partial<FieldServiceRecord>): string => {
    const normalizedValues = FIELD_SERVICE_IMPORT_COMPARISON_FIELDS.map((field) =>
      normalizeImportComparisonValue(field, record[field]),
    );
    return normalizedValues.some(Boolean) ? normalizedValues.join('|') : '';
  };

  type FieldServiceImportIndex = {
    byTag: Map<string, FieldServiceRecord[]>;
    byCertificate: Map<string, FieldServiceRecord[]>;
    byFingerprint: Map<string, FieldServiceRecord[]>;
  };

  const addFieldServiceRecordToImportIndex = (
    index: FieldServiceImportIndex,
    record: FieldServiceRecord,
  ) => {
    const append = (map: Map<string, FieldServiceRecord[]>, key: string) => {
      if (!key) return;
      const bucket = map.get(key);
      if (bucket) bucket.push(record);
      else map.set(key, [record]);
    };

    append(index.byTag, normalizeImportTag(record.tag));
    append(index.byCertificate, normalizeCertificateIdentity(record.certificate));
    append(index.byFingerprint, buildFieldServiceContentFingerprint(record));
  };

  const removeFieldServiceRecordFromImportIndex = (
    index: FieldServiceImportIndex,
    record: FieldServiceRecord,
  ) => {
    const remove = (map: Map<string, FieldServiceRecord[]>, key: string) => {
      if (!key) return;
      const bucket = map.get(key);
      if (!bucket) return;
      const remaining = bucket.filter((candidate) => candidate.id !== record.id);
      if (remaining.length > 0) map.set(key, remaining);
      else map.delete(key);
    };

    remove(index.byTag, normalizeImportTag(record.tag));
    remove(index.byCertificate, normalizeCertificateIdentity(record.certificate));
    remove(index.byFingerprint, buildFieldServiceContentFingerprint(record));
  };

  const createFieldServiceImportIndex = (candidateRecords: FieldServiceRecord[]): FieldServiceImportIndex => {
    const index: FieldServiceImportIndex = {
      byTag: new Map(),
      byCertificate: new Map(),
      byFingerprint: new Map(),
    };
    candidateRecords.forEach((record) => addFieldServiceRecordToImportIndex(index, record));
    return index;
  };

  const replaceFieldServiceRecordInImportIndex = (
    index: FieldServiceImportIndex,
    previousRecord: FieldServiceRecord,
    nextRecord: FieldServiceRecord,
  ) => {
    removeFieldServiceRecordFromImportIndex(index, previousRecord);
    addFieldServiceRecordToImportIndex(index, nextRecord);
  };

  const findUniqueFieldServiceImportMatch = (
    incoming: Partial<FieldServiceRecord>,
    index: FieldServiceImportIndex,
  ): { record?: FieldServiceRecord; ambiguous?: boolean; reason?: string } => {
    const incomingTag = normalizeImportTag(incoming.tag);
    const incomingCertificate = normalizeCertificateIdentity(incoming.certificate);

    const tagMatches = incomingTag ? (index.byTag.get(incomingTag) || []) : [];
    const certificateMatches = incomingCertificate ? (index.byCertificate.get(incomingCertificate) || []) : [];

    if (tagMatches.length > 1) {
      return {
        ambiguous: true,
        reason: `A TAG do Cliente "${incomingTag}" já possui ${tagMatches.length} registros ativos no sistema.`,
      };
    }
    if (certificateMatches.length > 1) {
      return {
        ambiguous: true,
        reason: `O Certificado "${incomingCertificate}" já possui ${certificateMatches.length} registros ativos no sistema.`,
      };
    }

    const tagMatch = tagMatches[0];
    const certificateMatch = certificateMatches[0];
    if (tagMatch && certificateMatch && tagMatch.id !== certificateMatch.id) {
      return {
        ambiguous: true,
        reason: `A TAG do Cliente "${incomingTag}" e o Certificado "${incomingCertificate}" apontam para registros diferentes.`,
      };
    }

    const identifierMatch = tagMatch || certificateMatch;
    if (identifierMatch) return { record: identifierMatch };

    // Regra existente preservada: quando TAG e Certificado estão vazios,
    // o desempate continua usando exatamente o mesmo fingerprint dos demais campos.
    if (!incomingTag && !incomingCertificate) {
      const contentFingerprint = buildFieldServiceContentFingerprint(incoming);
      if (!contentFingerprint) return {};

      const contentMatches = index.byFingerprint.get(contentFingerprint) || [];
      if (contentMatches.length === 1) return { record: contentMatches[0] };
      if (contentMatches.length > 1) {
        return {
          ambiguous: true,
          reason: `Foram encontrados ${contentMatches.length} registros equivalentes pelos demais campos, sem TAG e Certificado para desempate.`,
        };
      }
    }

    return {};
  };

  const mergeImportedFieldServiceRecord = (
    existing: FieldServiceRecord,
    incoming: Omit<FieldServiceRecord, 'id'>,
  ): Omit<FieldServiceRecord, 'id'> => {
    const merged: Omit<FieldServiceRecord, 'id'> = { ...incoming };
    for (const field of Object.keys(incoming) as Array<keyof Omit<FieldServiceRecord, 'id'>>) {
      const incomingValue = incoming[field];
      if (String(incomingValue ?? '').trim() === '') {
        (merged as any)[field] = (existing as any)[field] ?? '';
      }
    }
    merged.tag = normalizeImportTag(merged.tag);
    merged.certificate = normalizeCertificateIdentity(merged.certificate);
    return merged;
  };


  const normalizeCertificateIdentity = (value: unknown): string =>
    String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .trim()
      .replace(/\s+/g, '')
      .toUpperCase();
  const certificateDigits = (value: unknown) => normalizeCertificateIdentity(value).replace(/\D/g, '');

  // LOTE 41 — índice em memória O(1). Antes, cada linha/filtro fazia
  // instruments.find(...), multiplicando milhares de registros por milhares de
  // instrumentos. Com ~17 mil serviços isso era o principal gargalo de CPU.
  const instrumentLookup = useMemo(() => {
    const byCertificate = new Map<string, Instrument>();
    const byNumericCertificate = new Map<string, Instrument>();
    const clientIdsByTag = new Map<string, Set<string>>();

    for (const instrument of instruments) {
      const candidates = [instrument.certificateNumber, instrument.coma];
      for (const candidate of candidates) {
        const normalized = normalizeCertificateIdentity(candidate);
        if (normalized && !byCertificate.has(normalized)) byCertificate.set(normalized, instrument);
        const numeric = certificateDigits(candidate);
        if (numeric && !byNumericCertificate.has(numeric)) byNumericCertificate.set(numeric, instrument);
      }

      const tagKey = String(instrument.tag || '').trim().toUpperCase();
      const clientId = String(instrument.clientId || '').trim();
      if (tagKey && clientId) {
        const ids = clientIdsByTag.get(tagKey) || new Set<string>();
        ids.add(clientId);
        clientIdsByTag.set(tagKey, ids);
      }
    }

    return { byCertificate, byNumericCertificate, clientIdsByTag };
  }, [instruments]);

  const findInstrumentByCertificate = (certificate: unknown): Instrument | undefined => {
    const normalized = normalizeCertificateIdentity(certificate);
    if (!normalized) return undefined;
    const exact = instrumentLookup.byCertificate.get(normalized);
    if (exact) return exact;
    const numeric = certificateDigits(normalized);
    return numeric ? instrumentLookup.byNumericCertificate.get(numeric) : undefined;
  };

  const formatCalibrationDate = (value: unknown): string => {
    const raw = String(value || '').trim();
    if (!raw) return '';
    const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) return `${iso[3]}/${iso[2]}/${iso[1]}`;
    return raw;
  };

  const resolveCalibrationDate = (record: Partial<FieldServiceRecord>): string => {
    const instrument = findInstrumentByCertificate(record.certificate);
    return formatCalibrationDate(instrument?.lastCalibrationDate || record.dataCalibracao || '');
  };

  const loadComaninsLogoBytes = async (): Promise<Uint8Array> => {
    const response = await fetch('/COMANINS%202026_logo_horizontal_transparente.png', { cache: 'force-cache' });
    if (!response.ok) throw new Error('Não foi possível carregar a logo COMANINS.');
    return new Uint8Array(await response.arrayBuffer());
  };

  const triggerWorkbookDownload = (bytes: Uint8Array, fileName: string) => {
    const workbookBuffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
    const blob = new Blob([workbookBuffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = fileName;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  };

  const normalizeClientName = (value: unknown): string =>
    String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, '');

  const resolveClientId = (record: Partial<FieldServiceRecord>): string => {
    // O campo Cliente do Serviço de Campo é a fonte autoritativa do vínculo.
    // Não derivar cliente por certificado, TAG, unidade ou regra especial Braskem.
    const normalizedClient = normalizeClientName(record.cliente);
    if (normalizedClient) {
      const matchedClient = clients.find(
        (client) => normalizeClientName(client.name) === normalizedClient,
      );
      return matchedClient?.id ? String(matchedClient.id).trim() : '';
    }

    // Mantém o vínculo existente apenas para registros legados sem Cliente preenchido.
    return String(record.clientId || '').trim();
  };

  const handleRefreshRecords = async () => {
    setIsRefreshingRecords(true);
    try {
      await refreshFieldServiceRecords({ force: true, silent: true });
    } catch (error) {
      console.error(error);
      alert('Não foi possível atualizar os registros de Serviço de Campo.');
    } finally {
      setIsRefreshingRecords(false);
    }
  };

  const handleClearAllFieldServiceData = async () => {
    if (!canClearData) {
      setClearDataError('Somente o administrador logado pode limpar os dados de Serviço de Campo.');
      return;
    }
    if (!clearDataPassword) {
      setClearDataError('Digite a senha do administrador logado.');
      return;
    }

    setIsClearingData(true);
    setClearDataError('');
    try {
      const clearedCount = await clearAllFieldServiceRecords(clearDataPassword);
      setSelectedRecordIds(new Set());
      setCurrentPage(1);
      setShowClearDataModal(false);
      setClearDataPassword('');
      alert(`${clearedCount} registro(s) de Serviço de Campo foram removidos da base ativa com sucesso.`);
    } catch (error: any) {
      console.error('Erro ao limpar dados de Serviço de Campo:', error);
      setClearDataError(error?.message || 'Não foi possível limpar os dados de Serviço de Campo.');
    } finally {
      setIsClearingData(false);
    }
  };

  const handleDownloadTemplate = () => {
    const ws = XLSX.utils.json_to_sheet([{
      'Certificado': '',
      'Data Calibração': '',
      'Data de Intervenção': '',
      'TAG do Cliente': '',
      'Equipamento': '',
      'Localização': '',
      'Técnico': '',
      'Área': '',
      'Range': '',
      'Operação': '',
      'Unidade de Medida': '',
      'Categoria': '',
      'Emissão PDF': '',
      'Ordem de Serviço': '',
      'Tipo de Serviço': '',
      'Observação': '',
      'Unidade': '',
      'Cliente': ''
    }]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Modelo");
    XLSX.writeFile(wb, "Modelo_Importacao_Servico_Campo.xlsx");
  };

  const handleExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!canEdit) {
      e.target.value = '';
      alert("Seu perfil possui somente permissão de visualização no módulo Serviço de Campo.");
      return;
    }
    const file = e.target.files?.[0];
    if (!file) return;

    type ImportIssue = {
      sourceRow: number;
      status: string;
      reason: string;
      suggestedAction: string;
      record: Omit<FieldServiceRecord, 'id'>;
    };

    const getImportValue = (normalizedRow: Record<string, any>, aliases: string[]): any => {
      let firstDefined: any = '';
      let hasDefined = false;
      for (const alias of aliases) {
        const key = normalizeKey(alias);
        if (!Object.prototype.hasOwnProperty.call(normalizedRow, key)) continue;
        const value = normalizedRow[key];
        if (!hasDefined) {
          firstDefined = value;
          hasDefined = true;
        }
        if (String(value ?? '').trim() !== '') return value;
      }
      return hasDefined ? firstDefined : '';
    };

    const makeIssueReports = async (issues: ImportIssue[]): Promise<{ excelGenerated: boolean; pdfGenerated: boolean }> => {
      if (issues.length === 0) return { excelGenerated: false, pdfGenerated: false };

      const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
      let excelGenerated = false;
      let pdfGenerated = false;

      // Mantém o relatório Excel já existente para não remover funcionalidade homologada.
      try {
        const rows = issues.map((issue) => ({
          'Linha de Origem': issue.sourceRow,
          'Status': issue.status,
          'Motivo': issue.reason,
          'Ação Sugerida': issue.suggestedAction,
          'Certificado': issue.record.certificate || '',
          'Data Calibração': issue.record.dataCalibracao || '',
          'Data de Intervenção': issue.record.interventionDate || '',
          'TAG do Cliente': issue.record.tag || '',
          'Equipamento': issue.record.equipamento || '',
          'Localização': issue.record.localizacao || '',
          'Técnico': issue.record.technician || '',
          'Área': issue.record.area || '',
          'Range': issue.record.range || '',
          'Operação': issue.record.operacao || '',
          'Unidade de Medida': issue.record.unidadeMedida || '',
          'Categoria': issue.record.categoria || '',
          'Emissão PDF': issue.record.emissaoPdf || '',
          'Ordem de Serviço': issue.record.ordemServico || '',
          'Tipo de Serviço': issue.record.tipoServico || '',
          'Observação': issue.record.observacao || '',
          'Unidade': issue.record.unidade || '',
          'Cliente': issue.record.cliente || '',
        }));
        const worksheet = XLSX.utils.json_to_sheet(rows);
        worksheet['!cols'] = [
          { wch: 14 }, { wch: 22 }, { wch: 58 }, { wch: 42 },
          { wch: 16 }, { wch: 16 }, { wch: 18 }, { wch: 20 }, { wch: 24 }, { wch: 30 },
          { wch: 22 }, { wch: 18 }, { wch: 16 }, { wch: 18 }, { wch: 18 }, { wch: 18 },
          { wch: 16 }, { wch: 20 }, { wch: 22 }, { wch: 42 }, { wch: 18 }, { wch: 24 },
        ];
        worksheet['!autofilter'] = { ref: worksheet['!ref'] || 'A1:V1' };
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Nao_Inseridos');
        XLSX.writeFile(workbook, `RELATORIO_IMPORTACAO_SERVICO_CAMPO_NAO_INSERIDOS_${stamp}.xlsx`);
        excelGenerated = true;
      } catch (reportError) {
        console.error('Erro ao gerar relatório Excel de inconsistências:', reportError);
      }

      try {
        setImportProgress({
          percent: 96,
          stage: 'Gerando relatório PDF de inconsistências...',
          processed: issues.length,
          total: issues.length,
        });
        await yieldToBrowser();

        const { jsPDF } = await import('jspdf');
        const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4', compress: true });
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        const margin = 12;
        const contentWidth = pageWidth - (margin * 2);
        let y = 14;

        const drawHeader = () => {
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(14);
          doc.text('COMANINS - Relatório de Inconsistências da Importação', margin, y);
          y += 6;
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8.5);
          doc.text(`Arquivo importado: ${file.name}`, margin, y);
          y += 4;
          doc.text(`Gerado em: ${new Date().toLocaleString('pt-BR')} | Total de inconsistências: ${issues.length}`, margin, y);
          y += 5;
          const note = doc.splitTextToSize(
            'Relatório exclusivamente diagnóstico. As regras existentes de importação, inclusão, atualização, duplicidade, conflito e rejeição permanecem inalteradas.',
            contentWidth,
          );
          doc.text(note, margin, y);
          y += (note.length * 3.5) + 4;
        };

        const ensureSpace = (needed: number) => {
          if (y + needed <= pageHeight - 10) return;
          doc.addPage();
          y = 14;
          drawHeader();
        };

        drawHeader();
        for (let issueIndex = 0; issueIndex < issues.length; issueIndex++) {
          const issue = issues[issueIndex];
          const identification = [
            `Linha: ${issue.sourceRow || '-'}`,
            `Status: ${issue.status}`,
            `Certificado: ${issue.record.certificate || '-'}`,
            `TAG: ${issue.record.tag || '-'}`,
            `Cliente: ${issue.record.cliente || '-'}`,
            `Unidade: ${issue.record.unidade || '-'}`,
          ].join(' | ');
          const idLines = doc.splitTextToSize(identification, contentWidth);
          const reasonLines = doc.splitTextToSize(`Motivo: ${issue.reason}`, contentWidth);
          const actionLines = doc.splitTextToSize(`Ação sugerida: ${issue.suggestedAction}`, contentWidth);
          const needed = ((idLines.length + reasonLines.length + actionLines.length) * 3.5) + 8;
          ensureSpace(needed);

          doc.setFont('helvetica', 'bold');
          doc.setFontSize(8.5);
          doc.text(idLines, margin, y);
          y += idLines.length * 3.5 + 1;
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8);
          doc.text(reasonLines, margin, y);
          y += reasonLines.length * 3.5 + 1;
          doc.text(actionLines, margin, y);
          y += actionLines.length * 3.5 + 4;

          if ((issueIndex + 1) % 50 === 0) await yieldToBrowser();
        }

        doc.save(`RELATORIO_IMPORTACAO_SERVICO_CAMPO_INCONSISTENCIAS_${stamp}.pdf`);
        pdfGenerated = true;
      } catch (reportError) {
        console.error('Erro ao gerar relatório PDF de inconsistências:', reportError);
      }

      return { excelGenerated, pdfGenerated };
    };

    const emptyParsedRecord = (): Omit<FieldServiceRecord, 'id'> => ({
      clientId: '',
      cliente: '',
      tag: '',
      equipamento: '',
      localizacao: '',
      certificate: '',
      dataCalibracao: '',
      interventionDate: '',
      technician: '',
      area: '',
      range: '',
      operacao: '',
      unidadeMedida: '',
      categoria: '',
      emissaoPdf: '',
      ordemServico: '',
      tipoServico: '',
      observacao: '',
      unidade: '',
    });

    setIsImporting(true);
    setImportProgress({ percent: 1, stage: 'Carregando arquivo Excel...', processed: 0, total: 0 });

    const reader = new FileReader();
    reader.onprogress = (event) => {
      if (!event.lengthComputable) return;
      const percent = Math.max(1, Math.min(8, Math.round((event.loaded / event.total) * 8)));
      setImportProgress({ percent, stage: 'Carregando arquivo Excel...', processed: 0, total: 0 });
    };

    reader.onload = async (evt) => {
      const issues: ImportIssue[] = [];
      let issueReportsGenerated = false;
      let lastReportResult = { excelGenerated: false, pdfGenerated: false };
      const ensureIssueReports = async () => {
        if (issueReportsGenerated || issues.length === 0) return lastReportResult;
        issueReportsGenerated = true;
        lastReportResult = await makeIssueReports(issues);
        return lastReportResult;
      };

      try {
        const buffer = evt.target?.result;
        if (!(buffer instanceof ArrayBuffer)) {
          throw new Error('Não foi possível carregar o arquivo Excel selecionado.');
        }

        setImportProgress({ percent: 10, stage: 'Interpretando a planilha em segundo plano...', processed: 0, total: 0 });
        await yieldToBrowser();
        const data = await parseFieldServiceExcelInWorker(buffer);
        const totalRows = data.length;

        setImportProgress({ percent: 18, stage: 'Preparando comparação com a base atual...', processed: 0, total: totalRows });
        await yieldToBrowser();

        let addedCount = 0;
        let updatedCount = 0;
        let skippedCount = 0;
        let conflictCount = 0;

        const newRecordsToImport: Omit<FieldServiceRecord, 'id'>[] = [];
        const recordsToUpdate: { id: string; data: Partial<FieldServiceRecord> }[] = [];
        const workingIndex = createFieldServiceImportIndex(records);
        const processedTags = new Map<string, number>();
        const processedCertificates = new Map<string, number>();
        const processedContentFingerprints = new Map<string, number>();
        const processedExistingRecordIds = new Map<string, number>();

        for (let rowIndex = 0; rowIndex < data.length; rowIndex++) {
          const row = data[rowIndex];
          const sourceRow = Number.isFinite(Number((row as any)?.__rowNum__))
            ? Number((row as any).__rowNum__) + 1
            : rowIndex + 2;
          const normalizedRow = Object.keys(row).reduce((acc, key) => {
            if (key !== '__rowNum__') acc[normalizeKey(key)] = row[key];
            return acc;
          }, {} as Record<string, any>);

          const parsedRecord = emptyParsedRecord();
          parsedRecord.certificate = normalizeCertificateIdentity(getImportValue(normalizedRow, [
            'certificado', 'cert', 'certintervencao', 'cert intervenção', 'cert intervencao',
          ]));
          parsedRecord.dataCalibracao = normalizeImportDate(getImportValue(normalizedRow, [
            'data calibracao', 'data de calibracao', 'datacalibracao', 'dtcalibracao',
          ]));
          parsedRecord.interventionDate = normalizeImportDate(getImportValue(normalizedRow, [
            'data', 'date', 'data de intervencao', 'dataintervencao', 'dtintervencao',
            'dtintevencao', 'data de int', 'datadeint',
          ]));
          parsedRecord.tag = normalizeImportTag(getImportValue(normalizedRow, [
            'tag do cliente', 'tag cliente', 'tag',
          ]));
          parsedRecord.equipamento = String(getImportValue(normalizedRow, [
            'equipamento', 'equip', 'descricao', 'descrição', 'descrio',
          ]) ?? '').trim();
          parsedRecord.localizacao = String(getImportValue(normalizedRow, [
            'localizacao', 'localização', 'localiz', 'local', 'serie', 'série', 'srie',
          ]) ?? '').trim();
          parsedRecord.technician = String(getImportValue(normalizedRow, [
            'tecnico', 'técnico', 'technician', 'executante', 'executor',
          ]) ?? '').trim();
          parsedRecord.area = String(getImportValue(normalizedRow, ['area', 'área']) ?? '').trim();
          parsedRecord.range = String(getImportValue(normalizedRow, ['range', 'faixa']) ?? '').trim();
          parsedRecord.operacao = String(getImportValue(normalizedRow, ['operacao', 'operação', 'op']) ?? '').trim();
          parsedRecord.unidadeMedida = String(getImportValue(normalizedRow, [
            'unidade de medida', 'unidadedemedida', 'unidade medida', 'um', 'medida',
          ]) ?? '').trim();
          parsedRecord.categoria = String(getImportValue(normalizedRow, ['categoria', 'cat']) ?? '').trim();
          parsedRecord.emissaoPdf = String(getImportValue(normalizedRow, [
            'emissao pdf', 'emissão pdf', 'emissaopdf', 'pdf',
          ]) ?? '').trim();
          parsedRecord.ordemServico = String(getImportValue(normalizedRow, [
            'ordem de servico', 'ordem de serviço', 'ordemservico', 'os',
          ]) ?? '').trim();
          parsedRecord.tipoServico = String(getImportValue(normalizedRow, [
            'tipo de servico', 'tipo de serviço', 'tiposervico', 'servico', 'serviço',
          ]) ?? '').trim();
          parsedRecord.observacao = String(getImportValue(normalizedRow, [
            'observacao', 'observação', 'obs', 'notas',
          ]) ?? '').trim();
          parsedRecord.unidade = String(getImportValue(normalizedRow, ['unidade', 'unit']) ?? '').trim();
          parsedRecord.cliente = String(getImportValue(normalizedRow, ['cliente', 'client']) ?? '').trim();

          const normalizedTag = normalizeImportTag(parsedRecord.tag);
          const normalizedCert = normalizeCertificateIdentity(parsedRecord.certificate);
          const contentFingerprint = buildFieldServiceContentFingerprint(parsedRecord);

          if (normalizedTag && processedTags.has(normalizedTag)) {
            skippedCount++;
            issues.push({
              sourceRow,
              status: 'NÃO INSERIDO - TAG DUPLICADA NO ARQUIVO',
              reason: `A TAG do Cliente "${normalizedTag}" já apareceu na linha ${processedTags.get(normalizedTag)} desta importação.`,
              suggestedAction: 'Mantenha apenas uma linha para esta TAG ou corrija a identificação antes de importar novamente.',
              record: parsedRecord,
            });
            continue;
          }

          if (normalizedCert && processedCertificates.has(normalizedCert)) {
            skippedCount++;
            issues.push({
              sourceRow,
              status: 'NÃO INSERIDO - CERTIFICADO DUPLICADO NO ARQUIVO',
              reason: `O Certificado "${normalizedCert}" já apareceu na linha ${processedCertificates.get(normalizedCert)} desta importação.`,
              suggestedAction: 'Mantenha apenas uma linha para este certificado ou corrija o número antes de importar novamente.',
              record: parsedRecord,
            });
            continue;
          }

          if (!normalizedTag && !normalizedCert && contentFingerprint && processedContentFingerprints.has(contentFingerprint)) {
            skippedCount++;
            issues.push({
              sourceRow,
              status: 'NÃO INSERIDO - REGISTRO DUPLICADO NO ARQUIVO',
              reason: `TAG e Certificado estão em branco e todos os demais campos coincidem com a linha ${processedContentFingerprints.get(contentFingerprint)} desta importação.`,
              suggestedAction: 'Mantenha apenas uma das linhas equivalentes ou preencha os identificadores que diferenciam os registros.',
              record: parsedRecord,
            });
            continue;
          }

          const matchResult = findUniqueFieldServiceImportMatch(parsedRecord, workingIndex);
          if (matchResult.ambiguous) {
            conflictCount++;
            issues.push({
              sourceRow,
              status: 'NÃO INSERIDO - CONFLITO',
              reason: matchResult.reason || 'A linha encontrou mais de um registro possível e não foi alterada por segurança.',
              suggestedAction: 'Revise TAG, Certificado e os demais campos; corrija a duplicidade no sistema ou na planilha antes de tentar novamente.',
              record: parsedRecord,
            });
            continue;
          }

          const linkedInstrument = findInstrumentByCertificate(parsedRecord.certificate);
          if (linkedInstrument?.lastCalibrationDate) {
            parsedRecord.dataCalibracao = formatCalibrationDate(linkedInstrument.lastCalibrationDate);
          }
          parsedRecord.clientId = resolveClientId(parsedRecord);

          const existingMatch = matchResult.record;
          if (existingMatch) {
            if (processedExistingRecordIds.has(existingMatch.id)) {
              skippedCount++;
              issues.push({
                sourceRow,
                status: 'NÃO INSERIDO - MESMO REGISTRO JÁ PROCESSADO',
                reason: `Esta linha aponta para o mesmo registro do sistema já tratado pela linha ${processedExistingRecordIds.get(existingMatch.id)} desta importação.`,
                suggestedAction: 'Consolide as duas linhas em uma única linha antes de importar novamente.',
                record: parsedRecord,
              });
              continue;
            }

            const mergedRecord = mergeImportedFieldServiceRecord(existingMatch, parsedRecord);
            const finalTag = normalizeImportTag(mergedRecord.tag);
            const finalCertificate = normalizeCertificateIdentity(mergedRecord.certificate);

            const duplicateTagRecord = finalTag
              ? (workingIndex.byTag.get(finalTag) || []).find((record) => record.id !== existingMatch.id)
              : undefined;
            const duplicateCertificateRecord = finalCertificate
              ? (workingIndex.byCertificate.get(finalCertificate) || []).find((record) => record.id !== existingMatch.id)
              : undefined;

            if (duplicateTagRecord || duplicateCertificateRecord) {
              conflictCount++;
              issues.push({
                sourceRow,
                status: 'NÃO INSERIDO - IDENTIFICADOR JÁ UTILIZADO',
                reason: duplicateTagRecord
                  ? `A TAG do Cliente "${finalTag}" pertence a outro registro ativo.`
                  : `O Certificado "${finalCertificate}" pertence a outro registro ativo.`,
                suggestedAction: 'Corrija o identificador duplicado antes de importar novamente.',
                record: parsedRecord,
              });
              continue;
            }

            const hasDifferences = Object.keys(mergedRecord).some(
              (key) => String((mergedRecord as any)[key] ?? '') !== String((existingMatch as any)[key] ?? ''),
            );

            if (hasDifferences) {
              recordsToUpdate.push({ id: existingMatch.id, data: mergedRecord });
              const nextRecord = { ...existingMatch, ...mergedRecord } as FieldServiceRecord;
              replaceFieldServiceRecordInImportIndex(workingIndex, existingMatch, nextRecord);
              updatedCount++;
            } else {
              skippedCount++;
              issues.push({
                sourceRow,
                status: 'NÃO INSERIDO - JÁ EXISTENTE',
                reason: 'O registro já existe no sistema com os mesmos dados; nenhuma gravação adicional foi necessária.',
                suggestedAction: 'Nenhuma ação é necessária, a menos que queira alterar algum campo.',
                record: parsedRecord,
              });
            }
          } else {
            newRecordsToImport.push(parsedRecord);
            const syntheticRecord = {
              id: `__IMPORT_${sourceRow}_${newRecordsToImport.length}`,
              ...parsedRecord,
            } as FieldServiceRecord;
            addFieldServiceRecordToImportIndex(workingIndex, syntheticRecord);
            addedCount++;
          }

          if (normalizedTag) processedTags.set(normalizedTag, sourceRow);
          if (normalizedCert) processedCertificates.set(normalizedCert, sourceRow);
          if (!normalizedTag && !normalizedCert && contentFingerprint) {
            processedContentFingerprints.set(contentFingerprint, sourceRow);
          }
          if (existingMatch) processedExistingRecordIds.set(existingMatch.id, sourceRow);

          const processed = rowIndex + 1;
          if (processed % 50 === 0 || processed === totalRows) {
            const percent = totalRows > 0 ? 20 + Math.round((processed / totalRows) * 60) : 80;
            setImportProgress({
              percent: Math.min(80, percent),
              stage: 'Analisando e comparando registros...',
              processed,
              total: totalRows,
            });
            await yieldToBrowser();
          }
        }

        if (newRecordsToImport.length > 0 || recordsToUpdate.length > 0) {
          try {
            setImportProgress({
              percent: 84,
              stage: `Gravando ${newRecordsToImport.length} inclusão(ões) e ${recordsToUpdate.length} atualização(ões) pelo backend seguro...`,
              processed: totalRows,
              total: totalRows,
            });
            await yieldToBrowser();

            // Preserva a arquitetura atual: uma única chamada ao endpoint seguro
            // /api/field-service/bulk-upsert, com as mesmas regras do backend.
            const persistResult = await bulkUpsertFieldServiceRecords(recordsToUpdate, newRecordsToImport);
            addedCount = persistResult.addedCount;
            updatedCount = persistResult.updatedCount;
            conflictCount += persistResult.rejected.length;
            const rejectionLabel = (reason: string) => {
              if (reason === "DUPLICATE_TAG") return "TAG do Cliente já existente";
              if (reason === "DUPLICATE_CERTIFICATE") return "Certificado já existente";
              if (reason === "RECORD_NOT_FOUND") return "Registro a atualizar não foi encontrado";
              if (reason === "DUPLICATE_TARGET") return "Mais de uma operação tentou alterar o mesmo registro";
              return "Conflito de unicidade";
            };
            persistResult.rejected.forEach((rejection: any) => {
              const source = rejection.type === "add"
                ? newRecordsToImport[rejection.index]
                : recordsToUpdate[rejection.index]?.data;
              if (!source) return;
              issues.push({
                sourceRow: 0,
                status: "NÃO INSERIDO - REJEITADO PELO BANCO",
                reason: rejectionLabel(rejection.reason),
                suggestedAction: "Verifique se não há duplicidade gerada por outros usuários.",
                record: source as any,
              });
            });
          } catch (persistError: any) {
            console.error('Erro ao gravar importação de Serviço de Campo:', persistError);
            const genericRecord = emptyParsedRecord();
            issues.push({
              sourceRow: 0,
              status: 'ERRO DE GRAVAÇÃO DO LOTE',
              reason: persistError?.message || 'O sistema não conseguiu concluir a gravação do lote no banco de dados.',
              suggestedAction: 'Não repita a importação sem antes verificar se algum registro foi gravado. Atualize a tela, confira os dados e tente novamente somente com os itens pendentes.',
              record: genericRecord,
            });
            await ensureIssueReports();
            throw persistError;
          }
        }

        setImportProgress({ percent: 92, stage: 'Finalizando importação...', processed: totalRows, total: totalRows });
        await yieldToBrowser();
        const reportResult = await ensureIssueReports();

        setImportProgress({ percent: 100, stage: 'Importação concluída.', processed: totalRows, total: totalRows });
        await yieldToBrowser();

        const reportMessage = issues.length > 0
          ? reportResult.pdfGenerated && reportResult.excelGenerated
            ? `\n\nForam gerados automaticamente um PDF e uma planilha Excel com ${issues.length} item(ns) para tratamento.`
            : reportResult.pdfGenerated
              ? `\n\nFoi gerado automaticamente um PDF com ${issues.length} item(ns) para tratamento.`
              : reportResult.excelGenerated
                ? `\n\nO PDF não pôde ser gerado; foi mantida a planilha Excel com ${issues.length} item(ns) para tratamento.`
                : `\n\nForam encontradas ${issues.length} inconsistência(s), mas houve falha ao gerar os relatórios. Consulte o console antes de repetir a importação.`
          : '\n\nNenhuma inconsistência foi encontrada.';

        alert(
          `Importação concluída!\n\n${addedCount} novos registros adicionados.\n${updatedCount} registros atualizados.\n${skippedCount} não inseridos/ignorados.\n${conflictCount} conflitos não alterados por segurança.` +
          reportMessage,
        );
      } catch (error) {
        console.error("Error reading/importing excel:", error);
        const reportResult = await ensureIssueReports();
        if (issues.length === 0) {
          alert("Erro ao importar planilha. Verifique o formato do arquivo e tente novamente.");
        } else if (reportResult.pdfGenerated) {
          alert("A importação encontrou um erro. O relatório PDF de inconsistências foi gerado; confira os itens antes de tentar novamente.");
        } else {
          alert("A importação encontrou um erro. O relatório PDF não pôde ser gerado; confira o relatório Excel e o console antes de tentar novamente.");
        }
      } finally {
        setIsImporting(false);
        setImportProgress({ percent: 0, stage: '', processed: 0, total: 0 });
        if (excelInputRef.current) excelInputRef.current.value = '';
      }
    };

    reader.onerror = () => {
      setIsImporting(false);
      setImportProgress({ percent: 0, stage: '', processed: 0, total: 0 });
      if (excelInputRef.current) excelInputRef.current.value = '';
      alert('Erro ao carregar o arquivo Excel selecionado.');
    };

    reader.readAsArrayBuffer(file);
  };

  const handleExportExcel = () => {
    if (sortedRecords.length === 0) {
      alert("Nenhum registro encontrado para o filtro atual.");
      return;
    }

    const worksheet = XLSX.utils.json_to_sheet(sortedRecords.map((record) => ({
      'Certificado': record.certificate || '',
      'Data Calibração': resolveCalibrationDate(record) || '',
      'Data de Intervenção': record.interventionDate || '',
      'TAG do Cliente': record.tag || '',
      'Equipamento': record.equipamento || '',
      'Localização': record.localizacao || '',
      'Técnico': record.technician || '',
      'Área': record.area || '',
      'Range': record.range || '',
      'Operação': record.operacao || '',
      'Unidade de Medida': record.unidadeMedida || '',
      'Categoria': record.categoria || '',
      'Emissão PDF': record.emissaoPdf || '',
      'Ordem de Serviço': record.ordemServico || '',
      'Tipo de Serviço': record.tipoServico || '',
      'Observação': record.observacao || '',
      'Unidade': record.unidade || '',
      'Cliente': record.cliente || '',
    })));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'ServicoCampo');
    XLSX.writeFile(workbook, 'Servico_de_Campo_Export.xlsx');
  };

  const handleExportA4 = async () => {
    const exportRecords = sortedRecords.filter((record) => selectedRecordIds.has(record.id));
    if (exportRecords.length === 0) {
      alert("Selecione ao menos um registro na coluna Selecionar antes de gerar a Planilha A4.");
      return;
    }

    try {
      const logoPng = await loadComaninsLogoBytes();
      const workbookBytes = buildFieldServiceA4Workbook(
        exportRecords.map((record) => ({
          tag: String(record.tag || ''),
          equipamento: String(record.equipamento || ''),
          localizacao: String(record.localizacao || ''),
          area: String(record.area || ''),
          range: String(record.range || ''),
          operacao: String(record.operacao || ''),
          unidadeMedida: String(record.unidadeMedida || ''),
          certificate: String(record.certificate || ''),
          tipoServico: String(record.tipoServico || ''),
          ordemServico: String(record.ordemServico || ''),
          observacao: String(record.observacao || ''),
          unidade: String(record.unidade || ''),
        })),
        logoPng,
      );

      const uniqueUnits: string[] = Array.from(new Set<string>(
        exportRecords.map((record) => String(record.unidade || '').trim()).filter(Boolean),
      ));
      const suffix = (uniqueUnits.length === 1 ? uniqueUnits[0] : 'FILTRO')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-zA-Z0-9_-]+/g, '_');

      triggerWorkbookDownload(
        workbookBytes,
        `LISTA_DE_SERVICOS_${suffix || 'CAMPO'}.xlsx`,
      );
    } catch (error: any) {
      console.error(error);
      alert(error?.message || 'Não foi possível gerar a planilha A4.');
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!canEdit) {
      e.target.value = '';
      alert("Seu perfil possui somente permissão de visualização no módulo Serviço de Campo.");
      return;
    }
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingImage(true);
    try {
      let base64 = "";
      try {
        // Manuscritos exigem mais definição que uma foto de cadastro comum.
        base64 = await compressImageToWebResolution(file, 2200, 2200, 0.86);
      } catch {
        base64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = error => reject(error);
        });
      }

      const response = await authJsonFetch('/api/parse-field-service-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: base64, mode: 'table' })
      });

      const responseData = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(responseData.error || "Erro ao processar imagem.");
      }

      const extractedRows = Array.isArray(responseData.records)
        ? responseData.records
        : (responseData && typeof responseData === 'object' ? [responseData] : []);

      const rows = extractedRows
        .map((data: any) => {
          const certificate = String(data.certificate || '').trim();
          const linkedInstrument = findInstrumentByCertificate(certificate);
          return {
            'Certificado': certificate,
            'Data Calibração': formatCalibrationDate(linkedInstrument?.lastCalibrationDate || data.dataCalibracao || ''),
            'Data de Intervenção': dateMask(String(data.interventionDate || '')),
            'Tag': String(data.tag || ''),
            'Equipamento': String(data.equipamento || ''),
            'Localização': String(data.localizacao || ''),
            'Técnico': String(data.technician || ''),
            'Área': String(data.area || ''),
            'Range': String(data.range || ''),
            'Operação': String(data.operacao || ''),
            'Unidade de Medida': String(data.unidadeMedida || ''),
            'Categoria': String(data.categoria || ''),
            'Emissão PDF': String(data.emissaoPdf || ''),
            'Ordem de Serviço': String(data.ordemServico || ''),
            'Tipo de Serviço': String(data.tipoServico || ''),
            'Observação': String(data.observacao || ''),
            'Unidade': String(data.unidade || ''),
            'Cliente': String(data.cliente || ''),
          };
        })
        .filter((row: any) => Object.values(row).some((value) => String(value || '').trim() !== ''));

      if (rows.length === 0) {
        throw new Error('Nenhuma linha legível foi identificada na foto. Tente uma imagem mais nítida e bem enquadrada.');
      }

      const worksheet = XLSX.utils.json_to_sheet(rows);
      worksheet['!cols'] = [
        { wch: 16 }, { wch: 16 }, { wch: 18 }, { wch: 18 }, { wch: 26 }, { wch: 22 },
        { wch: 22 }, { wch: 16 }, { wch: 18 }, { wch: 18 }, { wch: 15 }, { wch: 16 },
        { wch: 14 }, { wch: 18 }, { wch: 20 }, { wch: 34 }, { wch: 18 }, { wch: 24 },
      ];
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Importacao');
      const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 12);
      XLSX.writeFile(workbook, `IMPORTACAO_SERVICO_CAMPO_IA_${stamp}.xlsx`);

      alert(`Leitura concluída: ${rows.length} linha(s) reconhecida(s).\n\nA planilha de importação foi gerada. Revise os dados e use o botão “Importar Planilha” no próprio Serviço de Campo.`);
    } catch (error: any) {
      console.error(error);
      alert("Falha na extração dos dados manuscritos: " + error.message);
    } finally {
      setIsProcessingImage(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };


  const dateMask = (value) => {
    if (!value) return '';
    return value
      .replace(/\D/g, "")
      .replace(/(\d{2})(\d)/, "$1/$2")
      .replace(/(\d{2})(\d)/, "$1/$2")
      .replace(/(\d{4})\d+?$/, "$1");
  };

  const handleSaveRecord = async () => {
    if (!canEdit) {
      alert("Seu perfil possui somente permissão de visualização no módulo Serviço de Campo.");
      setShowAddModal(false);
      return;
    }
    const normalizedFormCertificate = normalizeCertificateIdentity(formData.certificate);
    const normalizedFormTag = normalizeIdentityValue(formData.tag);
    const duplicateCert = Boolean(normalizedFormCertificate) && records.some(
      (r) => normalizeCertificateIdentity(r.certificate) === normalizedFormCertificate && r.id !== formData.id,
    );
    const duplicateTag = Boolean(normalizedFormTag) && records.some(
      (r) => normalizeIdentityValue(r.tag) === normalizedFormTag && r.id !== formData.id,
    );
    if (duplicateCert) {
      alert("Erro: Este Certificado já está registrado na planilha!");
      return;
    }
    if (duplicateTag) {
      alert("Erro: Esta TAG já está registrada na planilha!");
      return;
    }

    try {
      const linkedInstrument = findInstrumentByCertificate(formData.certificate);
      const recordToSave: Partial<FieldServiceRecord> = {
        ...formData,
        certificate: normalizeCertificateIdentity(formData.certificate),
        dataCalibracao: linkedInstrument?.lastCalibrationDate || formData.dataCalibracao || '',
        clientId: resolveClientId(formData),
      };
      if (formData.id) {
        await updateFieldServiceRecord(formData.id, recordToSave);
      } else {
        await addFieldServiceRecord(recordToSave as any);
      }
      setShowAddModal(false);
      setFormData({});
    } catch (e) {
      console.error(e);
      alert(e instanceof Error ? e.message : "Erro ao salvar registro.");
    }
  };

  const handleFilterChange = (field: string, val: string) => {
    setFilters(prev => ({...prev, [field]: val}));
    setCurrentPage(1); // reset to page 1 on filter
  };

  const toggleColumn = (id: string) => {
    setVisibleColumns(prev => ({ ...prev, [id]: !prev[id] }));
  };

  // Mantém digitação responsiva enquanto a busca percorre a base completa.
  const deferredFilters = useDeferredValue(filters);

  // A Data de Intervenção é a ordenação padrão. Converter a data uma vez por
  // registro evita recriar Date centenas de milhares de vezes no Array.sort().
  const interventionSortValues = useMemo(() => {
    const values = new Map<string, number>();
    records.forEach((record) => values.set(record.id, parseDateForSort(record.interventionDate)));
    return values;
  }, [records]);

  const needsCalibrationLookupForList = Boolean(deferredFilters.dataCalibracao)
    || sortConfig?.key === 'dataCalibracao';
  const calibrationLookupDependency = needsCalibrationLookupForList ? instrumentLookup : null;

  const sortedRecords = useMemo(() => {
    const activeFilters = Object.entries(deferredFilters)
      .filter(([, value]) => String(value || '').trim() !== '')
      .map(([key, value]) => [key, String(value).toLocaleLowerCase('pt-BR')] as const);

    let filtered = activeFilters.length === 0
      ? [...records]
      : records.filter((record) => activeFilters.every(([key, search]) => {
          const rawValue = key === 'dataCalibracao'
            ? resolveCalibrationDate(record)
            : (record as any)[key];
          return String(rawValue || '').toLocaleLowerCase('pt-BR').includes(search);
        }));

    if (sortConfig !== null) {
      filtered.sort((a, b) => {
        if (sortConfig.key === 'interventionDate') {
          const dateA = interventionSortValues.get(a.id) || 0;
          const dateB = interventionSortValues.get(b.id) || 0;
          return sortConfig.direction === 'asc' ? dateA - dateB : dateB - dateA;
        }
        if (sortConfig.key === 'dataCalibracao') {
          const dateA = parseDateForSort(resolveCalibrationDate(a));
          const dateB = parseDateForSort(resolveCalibrationDate(b));
          return sortConfig.direction === 'asc' ? dateA - dateB : dateB - dateA;
        }

        const valA = String((a as any)[sortConfig.key] || '').toLocaleLowerCase('pt-BR');
        const valB = String((b as any)[sortConfig.key] || '').toLocaleLowerCase('pt-BR');
        const comparison = valA.localeCompare(valB, 'pt-BR', { numeric: true, sensitivity: 'base' });
        return sortConfig.direction === 'asc' ? comparison : -comparison;
      });
    } else {
      filtered.sort((a, b) => (interventionSortValues.get(b.id) || 0) - (interventionSortValues.get(a.id) || 0));
    }

    return filtered;
  }, [records, deferredFilters, sortConfig, interventionSortValues, calibrationLookupDependency]);


  const duplicateAudit = useMemo(() => {
    const tagGroups = new Map<string, FieldServiceRecord[]>();
    const certificateGroups = new Map<string, FieldServiceRecord[]>();

    for (const record of records) {
      const tagKey = normalizeIdentityValue(record.tag);
      const certificateKey = normalizeCertificateIdentity(record.certificate);
      if (tagKey) {
        const group = tagGroups.get(tagKey) || [];
        group.push(record);
        tagGroups.set(tagKey, group);
      }
      if (certificateKey) {
        const group = certificateGroups.get(certificateKey) || [];
        group.push(record);
        certificateGroups.set(certificateKey, group);
      }
    }

    const rows: Record<string, any>[] = [];
    let tagGroupCount = 0;
    let certificateGroupCount = 0;
    const affectedRecordIds = new Set<string>();

    for (const [value, group] of tagGroups) {
      if (group.length < 2) continue;
      tagGroupCount++;
      group.forEach((record) => {
        affectedRecordIds.add(record.id);
        rows.push({
          'Tipo de Duplicidade': 'TAG do Cliente',
          'Valor Normalizado': value,
          'Quantidade no Grupo': group.length,
          'ID do Registro': record.id,
          'TAG do Cliente': record.tag || '',
          'Certificado': record.certificate || '',
          'Cliente': record.cliente || '',
          'Unidade': record.unidade || '',
          'Equipamento': record.equipamento || '',
          'Localização': record.localizacao || '',
          'Data de Intervenção': record.interventionDate || '',
        });
      });
    }

    for (const [value, group] of certificateGroups) {
      if (group.length < 2) continue;
      certificateGroupCount++;
      group.forEach((record) => {
        affectedRecordIds.add(record.id);
        rows.push({
          'Tipo de Duplicidade': 'Certificado',
          'Valor Normalizado': value,
          'Quantidade no Grupo': group.length,
          'ID do Registro': record.id,
          'TAG do Cliente': record.tag || '',
          'Certificado': record.certificate || '',
          'Cliente': record.cliente || '',
          'Unidade': record.unidade || '',
          'Equipamento': record.equipamento || '',
          'Localização': record.localizacao || '',
          'Data de Intervenção': record.interventionDate || '',
        });
      });
    }

    return {
      rows,
      tagGroupCount,
      certificateGroupCount,
      affectedRecordCount: affectedRecordIds.size,
    };
  }, [records]);

  const handleExportDuplicateAudit = () => {
    if (duplicateAudit.rows.length === 0) {
      alert('Nenhuma TAG do Cliente ou Certificado duplicado foi encontrado na base carregada.');
      return;
    }
    const worksheet = XLSX.utils.json_to_sheet(duplicateAudit.rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Duplicidades');
    const summary = XLSX.utils.json_to_sheet([{
      'Grupos de TAG duplicada': duplicateAudit.tagGroupCount,
      'Grupos de Certificado duplicado': duplicateAudit.certificateGroupCount,
      'Registros afetados': duplicateAudit.affectedRecordCount,
    }]);
    XLSX.utils.book_append_sheet(workbook, summary, 'Resumo');
    const stamp = new Date().toISOString().slice(0, 10);
    XLSX.writeFile(workbook, `CONFERENCIA_DUPLICIDADES_SERVICO_CAMPO_${stamp}.xlsx`);
  };

  const selectedFilteredRecords = useMemo(
    () => sortedRecords.filter((record) => selectedRecordIds.has(record.id)),
    [sortedRecords, selectedRecordIds],
  );
  const allFilteredSelected = sortedRecords.length > 0 && selectedFilteredRecords.length === sortedRecords.length;
  const someFilteredSelected = selectedFilteredRecords.length > 0 && !allFilteredSelected;

  const toggleRecordSelection = (recordId: string) => {
    setSelectedRecordIds((current) => {
      const next = new Set(current);
      if (next.has(recordId)) next.delete(recordId);
      else next.add(recordId);
      return next;
    });
  };

  const toggleAllFilteredRecords = () => {
    setSelectedRecordIds((current) => {
      const next = new Set(current);
      if (allFilteredSelected) {
        sortedRecords.forEach((record) => next.delete(record.id));
      } else {
        sortedRecords.forEach((record) => next.add(record.id));
      }
      return next;
    });
  };

  useEffect(() => {
    const existingIds = new Set(records.map((record) => record.id));
    setSelectedRecordIds((current) => {
      const next = new Set(Array.from(current).filter((id) => existingIds.has(id)));
      if (next.size === current.size && Array.from(next).every((id) => current.has(id))) return current;
      return next;
    });
  }, [records]);

  const totalPages = Math.ceil(sortedRecords.length / itemsPerPage);
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return sortedRecords.slice(start, start + itemsPerPage);
  }, [sortedRecords, currentPage, itemsPerPage]);

  useEffect(() => {
    const tableScroller = tableScrollRef.current;
    if (!tableScroller) return;
    const updateWidth = () => setTableScrollWidth(tableScroller.scrollWidth);
    updateWidth();
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(updateWidth) : null;
    observer?.observe(tableScroller);
    window.addEventListener('resize', updateWidth);
    return () => {
      observer?.disconnect();
      window.removeEventListener('resize', updateWidth);
    };
  }, [paginatedRecords.length, visibleColumns]);

  const syncTopScroll = () => {
    if (topScrollRef.current && tableScrollRef.current) {
      tableScrollRef.current.scrollLeft = topScrollRef.current.scrollLeft;
    }
  };

  const syncTableScroll = () => {
    if (topScrollRef.current && tableScrollRef.current) {
      topScrollRef.current.scrollLeft = tableScrollRef.current.scrollLeft;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Serviço de Campo</h2>
          <p className="text-sm text-slate-500">Gerencie registros, importe em lote e utilize filtros completos.</p>
        </div>

        <div className="flex flex-wrap gap-2">
          {/* Hidden inputs */}
          <input type="file" accept=".xlsx,.xls,.csv" ref={excelInputRef} className="hidden" onChange={handleExcelImport} />
          <input type="file" accept="image/*,.heic,.heif" ref={fileInputRef} className="hidden" onChange={handleImageUpload} />

          <button
            onClick={handleDownloadTemplate}
            className="flex items-center space-x-2 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold rounded-lg transition-colors text-sm"
          >
            <FileDown className="h-4 w-4" />
            <span>Modelo Planilha</span>
          </button>

          {canEdit && (
            <button
              onClick={() => excelInputRef.current?.click()}
              disabled={isImporting}
              className="flex items-center space-x-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg transition-colors text-sm disabled:opacity-50"
            >
              {isImporting ? <RefreshCw className="h-4 w-4 animate-spin" /> : <FileSpreadsheet className="h-4 w-4" />}
              <span>{isImporting ? 'Importando...' : 'Importar Planilha'}</span>
            </button>
          )}

          <button
            onClick={handleExportExcel}
            className="flex items-center space-x-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg transition-colors text-sm"
            title="Exporta os registros do filtro atual em um arquivo Excel editável"
          >
            <Download className="h-4 w-4" />
            <span>Exportar Excel</span>
          </button>

          <button
            onClick={handleExportA4}
            className="flex items-center space-x-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg transition-colors text-sm"
            title="Gera somente os registros marcados na coluna Selecionar, em XLSX real com logo COMANINS e página A4 horizontal"
          >
            <Printer className="h-4 w-4" />
            <span>Gerar Planilha A4</span>
          </button>

          <button
            onClick={handleRefreshRecords}
            disabled={isRefreshingRecords}
            className="flex items-center space-x-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg transition-colors text-sm disabled:opacity-50"
            title="Atualização automática ativa. Use este botão apenas para forçar uma sincronização completa imediata."
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshingRecords ? 'animate-spin' : ''}`} />
            <span>Atualizar Dados</span>
          </button>

          {canClearData && (
            <button
              type="button"
              onClick={() => {
                setClearDataPassword('');
                setClearDataError('');
                setShowClearDataModal(true);
              }}
              className="flex items-center space-x-2 px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold rounded-lg transition-colors text-sm"
              title="Limpar todos os registros ativos de Serviço de Campo. Requer a senha do administrador atualmente logado."
            >
              <Trash2 className="h-4 w-4" />
              <span>Limpar Dados</span>
            </button>
          )}

          {canEdit && (
            <>
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isProcessingImage}
                className="flex items-center space-x-2 px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold rounded-lg transition-colors text-sm disabled:opacity-50"
              >
                {isProcessingImage ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
                <span>{isProcessingImage ? 'Lendo manuscritos...' : 'Foto → Planilha (IA)'}</span>
              </button>

              <button
                onClick={() => { setFormData({}); setShowAddModal(true); }}
                className="flex items-center space-x-2 px-3 py-2 bg-royal-blue hover:bg-blue-700 text-white font-semibold rounded-lg transition-colors text-sm"
              >
                <Plus className="h-4 w-4" />
                <span>Novo Registro</span>
              </button>
            </>
          )}
        </div>
      </div>

      {duplicateAudit.rows.length > 0 && (
        <div className="mb-4 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm font-bold text-amber-900">Duplicidades legadas encontradas em Serviço de Campo</p>
            <p className="text-xs text-amber-800 mt-1">
              {duplicateAudit.tagGroupCount} grupo(s) de TAG duplicada, {duplicateAudit.certificateGroupCount} grupo(s) de Certificado duplicado e {duplicateAudit.affectedRecordCount} registro(s) afetado(s). Novas gravações não poderão criar outra duplicidade.
            </p>
          </div>
          <button
            type="button"
            onClick={handleExportDuplicateAudit}
            className="shrink-0 flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-amber-900 text-white text-xs font-bold hover:bg-amber-800"
          >
            <FileDown className="h-4 w-4" />
            Exportar conferência
          </button>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-visible relative">
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center text-sm font-semibold text-slate-700">
              Filtros por coluna abaixo <span className="ml-2 text-xs font-normal text-slate-500">({sortedRecords.length} de {records.length})</span>
              <span className="ml-3 inline-flex items-center rounded-full bg-blue-100 px-2 py-0.5 text-[11px] font-bold text-blue-700">
                {selectedFilteredRecords.length} selecionado(s)
              </span>
              {selectedFilteredRecords.length > 0 && (
                <button
                  type="button"
                  onClick={() => setSelectedRecordIds(new Set())}
                  className="ml-2 text-[11px] font-bold text-slate-500 hover:text-rose-600 underline"
                >
                  Limpar seleção
                </button>
              )}
            </div>

            {/* Column Visibility Menu */}
            <div className="relative">
              <button
                onClick={() => setShowColumnMenu(!showColumnMenu)}
                className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-700 hover:bg-slate-50 transition-colors"
              >
                <Columns className="h-4 w-4" />
                Colunas
              </button>

              {showColumnMenu && (
                <div className="absolute top-full left-0 mt-2 w-56 bg-white border border-slate-200 rounded-lg shadow-xl z-20 py-2 max-h-80 overflow-y-auto">
                  <div className="px-3 pb-2 mb-2 border-b border-slate-100">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Visibilidade</span>
                  </div>
                  {COLUMNS.map(col => (
                    <label key={col.id} className="flex items-center gap-3 px-4 py-2 hover:bg-slate-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={visibleColumns[col.id]}
                        onChange={() => toggleColumn(col.id)}
                        className="rounded text-royal-blue focus:ring-royal-blue"
                      />
                      <span className="text-sm text-slate-700">{col.label}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-4">
             <div className="flex items-center gap-2 text-sm text-slate-600">
               <span>Página:</span>
               <select
                 value={itemsPerPage}
                 onChange={e => { setItemsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                 className="border-slate-300 rounded px-2 py-1 outline-none focus:ring-1 focus:ring-royal-blue"
               >
                 <option value={50}>50</option>
                 <option value={100}>100</option>
                 <option value={500}>500</option>
                 <option value={1000}>1000</option>
               </select>
             </div>

             <div className="flex items-center gap-2">
               <button
                 onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                 disabled={currentPage === 1}
                 className="p-1 rounded hover:bg-slate-200 disabled:opacity-50"
               >
                 <ChevronLeft className="h-5 w-5 text-slate-600" />
               </button>
               <span className="text-sm font-semibold text-slate-700">Página {currentPage} de {totalPages || 1}</span>
               <button
                 onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                 disabled={currentPage === totalPages || totalPages === 0}
                 className="p-1 rounded hover:bg-slate-200 disabled:opacity-50"
               >
                 <ChevronRight className="h-5 w-5 text-slate-600" />
               </button>
             </div>
          </div>
        </div>

        <div
          ref={topScrollRef}
          onScroll={syncTopScroll}
          className="overflow-x-auto overflow-y-hidden h-4 border-b border-slate-200 bg-slate-50"
          title="Rolagem horizontal superior"
        >
          <div style={{ width: `${tableScrollWidth}px`, height: '1px' }} />
        </div>
        <div ref={tableScrollRef} onScroll={syncTableScroll} className="overflow-x-auto min-h-[400px]">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-slate-700 text-xs uppercase font-bold border-b border-slate-200">
              <tr>
                <th className="px-3 py-3 min-w-[92px] text-center align-top">
                  <div className="flex flex-col items-center gap-2">
                    <span>Selecionar</span>
                    <input
                      type="checkbox"
                      checked={allFilteredSelected}
                      ref={(element) => { if (element) element.indeterminate = someFilteredSelected; }}
                      onChange={toggleAllFilteredRecords}
                      disabled={sortedRecords.length === 0}
                      className="h-4 w-4 rounded border-slate-300 text-royal-blue focus:ring-royal-blue"
                      title={allFilteredSelected ? 'Desmarcar todos os registros filtrados' : 'Selecionar todos os registros filtrados'}
                    />
                  </div>
                </th>
                {COLUMNS.filter(c => visibleColumns[c.id]).map(col => (
                  <th key={col.id} className="px-4 py-3" style={{ minWidth: col.minW }}>
                    <div
                      className="flex items-center gap-1 cursor-pointer hover:text-royal-blue select-none"
                      onClick={() => handleSort(col.id)}
                      title="Clique para ordenar"
                    >
                      {col.label}
                      {sortConfig?.key === col.id ? (
                        sortConfig.direction === 'asc' ? <ChevronUp className="w-3 h-3 text-royal-blue" /> : <ChevronDown className="w-3 h-3 text-royal-blue" />
                      ) : (
                        <ChevronsUpDown className="w-3 h-3 opacity-30 hover:opacity-100" />
                      )}
                    </div>
                    <input
                      type="text"
                      value={filters[col.id] || ''}
                      onChange={e => handleFilterChange(col.id, e.target.value)}
                      className="w-full mt-2 px-2 py-1.5 text-xs border border-slate-300 rounded bg-white font-normal outline-none focus:border-royal-blue"
                      placeholder="Filtrar..."
                    />
                  </th>
                ))}
                <th className="px-4 py-3 min-w-[80px]">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {isLoading ? (
                <tr><td colSpan={COLUMNS.filter(c => visibleColumns[c.id]).length + 2} className="text-center py-12 text-slate-500">Carregando registros...</td></tr>
              ) : paginatedRecords.length === 0 ? (
                <tr><td colSpan={COLUMNS.filter(c => visibleColumns[c.id]).length + 2} className="text-center py-12 text-slate-500">Nenhum registro encontrado.</td></tr>
              ) : (

                paginatedRecords.map(record => (
                  <tr key={record.id} className={`transition-colors ${selectedRecordIds.has(record.id) ? 'bg-blue-50/70 hover:bg-blue-50' : 'hover:bg-slate-50'}`}>
                    <td className="px-3 py-3 text-center align-middle">
                      <input
                        type="checkbox"
                        checked={selectedRecordIds.has(record.id)}
                        onChange={() => toggleRecordSelection(record.id)}
                        className="h-4 w-4 rounded border-slate-300 text-royal-blue focus:ring-royal-blue"
                        aria-label={`Selecionar TAG ${record.tag || record.id}`}
                      />
                    </td>
                    {COLUMNS.filter(c => visibleColumns[c.id]).map(col => {
                      let value = (record as any)[col.id];

                      if (col.id === 'dataCalibracao') {
                        value = resolveCalibrationDate(record) || '-';
                      }

                      const isEditing = canEdit && editingCell?.rowId === record.id && editingCell?.colId === col.id;
                      if (isEditing && col.id !== 'dataCalibracao') {
                        if (col.id === 'cliente') {
                          return (
                            <td key={col.id} className="px-4 py-2">
                              <select
                                autoFocus
                                defaultValue={value}
                                onChange={e => { void handleInlineSave(record, col.id, e.target.value); }}
                                onBlur={() => setEditingCell(null)}
                                onKeyDown={e => { if (e.key === 'Escape') setEditingCell(null); }}
                                className="w-full px-2 py-1 text-sm border border-royal-blue rounded outline-none shadow-sm bg-white"
                              >
                                <option value="">Selecione...</option>
                                {clients
                                  .slice()
                                  .sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'))
                                  .map(client => (
                                    <option key={client.id} value={client.name}>{client.name}</option>
                                  ))}
                              </select>
                            </td>
                          );
                        }

                        return (
                          <td key={col.id} className="px-4 py-2">
                            <input
                              autoFocus
                              defaultValue={value}
                              onBlur={e => handleInlineSave(record, col.id, e.target.value)}
                              onKeyDown={e => { if (e.key === 'Enter') e.currentTarget.blur(); if (e.key === 'Escape') setEditingCell(null); }}
                              className="w-full px-2 py-1 text-sm border border-royal-blue rounded outline-none shadow-sm"
                            />
                          </td>
                        );
                      }

                      // Special renderers (clickable for edit)
                      if (col.id === 'certificate' || col.id === 'tag') {
                        return <td key={col.id} className={`px-4 py-3 font-medium whitespace-nowrap ${canEdit ? 'cursor-pointer hover:bg-blue-50 transition-colors' : ''}`} onClick={() => canEdit && setEditingCell({rowId: record.id, colId: col.id})} title={canEdit ? "Clique para editar" : "Somente visualização"}>{value || '-'}</td>;
                      }

                      if (col.id === 'observacao') {
                        return <td key={col.id} className={`px-4 py-3 max-w-[200px] truncate ${canEdit ? 'cursor-pointer hover:bg-slate-100 transition-colors' : ''}`} title={canEdit ? "Clique para editar" : "Somente visualização"} onClick={() => canEdit && setEditingCell({rowId: record.id, colId: col.id})}>{value || '-'}</td>;
                      }

                      return <td key={col.id} className={`px-4 py-3 whitespace-nowrap ${canEdit ? 'cursor-pointer hover:bg-slate-100 transition-colors' : ''}`} title={canEdit ? "Clique para editar" : "Somente visualização"} onClick={() => canEdit && setEditingCell({rowId: record.id, colId: col.id})}>{value || '-'}</td>;
                    })}
                    <td className="px-4 py-3 whitespace-nowrap text-right">
                      {(() => {
                        const matchingInst = findInstrumentByCertificate(record.certificate);
                        if (matchingInst && onPrintCertificate) {
                          const context: FieldServiceCertificateContext = {
                            fieldServiceRecordId: record.id,
                            clientId: record.clientId,
                            cliente: record.cliente || '',
                            unidade: record.unidade || '',
                          };
                          return (
                            <button
                              onClick={() => onPrintCertificate(
                                matchingInst.id,
                                record.tag || '',
                                record.equipamento || '',
                                context,
                              )}
                              className="text-emerald-500 hover:text-emerald-600 mr-3"
                              title="Visualizar / imprimir Certificado de Calibração"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                          );
                        }
                        return null;
                      })()}
                      {canEdit && (
                        <>
                          <button onClick={() => { setFormData(record); setShowAddModal(true); }} className="text-slate-400 hover:text-royal-blue mr-3" title="Editar Formulário">
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button onClick={() => handleDeleteRecord(record.id)} className="text-slate-400 hover:text-red-500" title="Excluir">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isImporting && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/55 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-6 py-5 border-b border-slate-200 bg-slate-50">
              <div className="flex items-center gap-3">
                <RefreshCw className="h-6 w-6 animate-spin text-royal-blue" />
                <div>
                  <h3 className="font-bold text-slate-800">Importando Serviço de Campo</h3>
                  <p className="text-xs text-slate-500 mt-0.5">Aguarde a conclusão. A tela continuará atualizando o progresso.</p>
                </div>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <div className="flex items-center justify-between gap-3 mb-2">
                  <p className="text-sm font-semibold text-slate-700">{importProgress.stage || 'Processando...'}</p>
                  <span className="text-sm font-bold text-royal-blue">{Math.max(0, Math.min(100, importProgress.percent))}%</span>
                </div>
                <div className="h-3 rounded-full bg-slate-200 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-royal-blue transition-[width] duration-300 ease-out"
                    style={{ width: `${Math.max(2, Math.min(100, importProgress.percent))}%` }}
                  />
                </div>
              </div>
              {importProgress.total > 0 && (
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>Linhas processadas</span>
                  <span className="font-semibold text-slate-700">
                    {Math.min(importProgress.processed, importProgress.total).toLocaleString('pt-BR')} / {importProgress.total.toLocaleString('pt-BR')}
                  </span>
                </div>
              )}
              <div className="rounded-lg border border-blue-100 bg-blue-50 px-3 py-2 text-xs text-blue-800">
                A leitura pesada do Excel ocorre em segundo plano. As regras já existentes de importação não são modificadas por este processamento.
              </div>
            </div>
          </div>
        </div>
      )}

      {showClearDataModal && canClearData && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
            <div className="px-6 py-4 border-b border-slate-200 flex justify-between items-center bg-rose-50">
              <div>
                <h3 className="font-bold text-lg text-rose-800">Limpar dados de Serviço de Campo</h3>
                <p className="text-xs text-rose-700 mt-1">Ação restrita ao administrador atualmente logado.</p>
              </div>
              <button
                type="button"
                onClick={() => { if (!isClearingData) setShowClearDataModal(false); }}
                disabled={isClearingData}
                className="text-slate-400 hover:text-slate-600 disabled:opacity-50"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                Todos os registros ativos desta aba serão arquivados e sairão da listagem. Instrumentos, certificados, calibrações, clientes e demais módulos não serão excluídos.
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Senha do administrador logado</label>
                <input
                  type="password"
                  autoComplete="current-password"
                  value={clearDataPassword}
                  onChange={(event) => { setClearDataPassword(event.target.value); setClearDataError(''); }}
                  onKeyDown={(event) => { if (event.key === 'Enter' && !isClearingData) void handleClearAllFieldServiceData(); }}
                  disabled={isClearingData}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-rose-500 outline-none disabled:bg-slate-100"
                  placeholder="Digite sua senha"
                />
              </div>
              {clearDataError && (
                <p className="text-sm font-semibold text-rose-600">{clearDataError}</p>
              )}
            </div>
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowClearDataModal(false)}
                disabled={isClearingData}
                className="px-4 py-2 text-slate-600 font-semibold rounded-lg hover:bg-slate-200 transition-colors text-sm disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => void handleClearAllFieldServiceData()}
                disabled={isClearingData || !clearDataPassword}
                className="px-4 py-2 bg-rose-600 text-white font-bold rounded-lg hover:bg-rose-700 transition-colors flex items-center gap-2 text-sm shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isClearingData ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                {isClearingData ? 'Limpando...' : 'Confirmar limpeza'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showAddModal && canEdit && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-4xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-slate-200 flex justify-between items-center bg-slate-50">
              <h3 className="font-bold text-lg text-slate-800">
                {formData.id ? 'Editar Registro' : 'Novo Registro de Campo'}
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {COLUMNS.filter(c => c.id !== 'observacao' && c.id !== 'dataCalibracao').map(col => (
                  <div key={col.id}>
                    <label className="block text-xs font-bold text-slate-700 mb-1">{col.label}</label>
                    {col.id === 'cliente' ? (
                      <select
                        value={(formData as any)[col.id] || ''}
                        onChange={e => setFormData({...formData, cliente: e.target.value})}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-royal-blue outline-none bg-white"
                      >
                        <option value="">Selecione...</option>
                        {clients
                          .slice()
                          .sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'))
                          .map(client => (
                            <option key={client.id} value={client.name}>{client.name}</option>
                          ))}
                      </select>
                    ) : (
                      <input
                        type="text"
                        value={(formData as any)[col.id] || ''}
                        onChange={e => setFormData({...formData, [col.id]: e.target.value})}
                        className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-royal-blue outline-none"
                      />
                    )}
                  </div>
                ))}

                <div className="sm:col-span-3">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Observação</label>
                  <textarea
                    value={formData.observacao || ''}
                    onChange={e => setFormData({...formData, observacao: e.target.value})}
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-royal-blue outline-none min-h-[80px]"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-2">
              <button onClick={() => setShowAddModal(false)} className="px-4 py-2 text-slate-600 font-semibold rounded-lg hover:bg-slate-200 transition-colors text-sm">
                Cancelar
              </button>
              <button onClick={handleSaveRecord} className="px-4 py-2 bg-royal-blue text-white font-bold rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 text-sm shadow-sm">
                <Save className="h-4 w-4" />
                Salvar Registro
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
